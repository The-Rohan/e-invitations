import OrderJourney from '@/components/OrderJourney';
export default function Page(){return <OrderJourney/>}
