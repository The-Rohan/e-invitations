"use client";
import { useEffect, useRef, useState } from "react";
export default function Invitation({ id, preview = false }: { id: string; preview?: boolean }) {
  const frame = useRef<HTMLIFrameElement>(null);
  const [open, O] = useState(false),
    [message, M] = useState("");
  useEffect(() => {
    const listener = (e: MessageEvent) => {
      if (e.origin === location.origin && e.source === frame.current?.contentWindow && e.data?.type === "open-rsvp") O(true);
    };
    window.addEventListener("message", listener);
    return () => window.removeEventListener("message", listener);
  }, []);
  return (
    <div className="invitation">
      <iframe
        ref={frame}
        title="Your wedding invitation"
        src={"/api/invitation/" + encodeURIComponent(id) + (preview ? "?preview=1" : "")}
        allow="autoplay; fullscreen"
      />
      <button className="rsvp-float" onClick={() => O(true)}>
        Reply with love ♡
      </button>
      {open && (
        <div className="modal">
          <form
            className="panel"
            onSubmit={async (e) => {
              e.preventDefault();
              const f = new FormData(e.currentTarget);
              const r = await fetch("/api/platform", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                  action: "rsvp",
                  id,
                  name: f.get("name"),
                  count: Number(f.get("count")),
                  attending: f.get("attending") === "yes",
                }),
              });
              const d = await r.json();
              M(
                r.ok
                  ? "Thank you. Your reply has reached the couple."
                  : d.error,
              );
            }}
          >
            <button type="button" onClick={() => O(false)}>
              Close ×
            </button>
            <h2>A little reply, with love.</h2>
            <label>
              Your name
              <input name="name" required maxLength={100} />
            </label>
            <label>
              Your reply
              <select name="attending">
                <option value="yes">Happily attending</option>
                <option value="no">Sending love from afar</option>
              </select>
            </label>
            <label>
              Number of guests
              <input
                name="count"
                type="number"
                min="1"
                max="20"
                defaultValue="1"
                required
              />
            </label>
            <button className="button">Send my reply ♡</button>
            <p role="status">{message}</p>
          </form>
        </div>
      )}
    </div>
  );
}
