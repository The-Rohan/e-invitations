import { isCalendarDate, normalizeWhatsApp, type Details } from "./platform";
export type DetailIssue = { field: string; step: number; message: string };
export function detailIssues(value: unknown, maxEvents = 3): DetailIssue[] {
  const d = (value || {}) as Partial<Details>;
  const issues: DetailIssue[] = [];
  const add = (field: string, step: number, message: string) => issues.push({ field, step, message });
  for (const key of ["groom", "bride"] as const)
    if (typeof d[key] !== "string" || !d[key]!.trim()) add(key, 1, `Enter the ${key}’s name.`);
  if (typeof d.phone !== "string" || !/^\+?[\d\s()-]{10,24}$/.test(d.phone.trim()) || !/^[1-9]\d{9,14}$/.test(normalizeWhatsApp(d.phone)))
    add("phone", 1, "Enter the customer’s WhatsApp number, for example 03001063545 or +923001063545.");
  if (!Array.isArray(d.events) || !d.events.length) add("events", 2, "Add at least one event.");
  else {
    if (d.events.length > maxEvents) add("events", 2, `This package includes ${maxEvents} event${maxEvents === 1 ? "" : "s"}. Remove extra events or choose a larger package.`);
    d.events.forEach((event, i) => {
      const e = event || {};
      for (const key of ["name", "venue"] as const)
        if (typeof e[key] !== "string" || !e[key].trim()) add(`events.${i}.${key}`, 2, `Event ${i + 1}: enter the ${key === "name" ? "event name" : "venue name"}.`);
      if (typeof e.date !== "string" || !isCalendarDate(e.date)) add(`events.${i}.date`, 2, `Event ${i + 1}: choose a valid calendar date.`);
      if (typeof e.time !== "string" || !/^([01]\d|2[0-3]):[0-5]\d$/.test(e.time)) add(`events.${i}.time`, 2, `Event ${i + 1}: choose a valid time.`);
    });
  }
  return issues;
}
