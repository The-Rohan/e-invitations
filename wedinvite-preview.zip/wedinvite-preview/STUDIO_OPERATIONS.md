# WedInvite studio operations

## Customer journey
Browse `/templates` → read a design’s `/templates/{design}` page → WhatsApp +92 300 1063545. The studio collects names (optional Urdu names), WhatsApp number, up to three events with dates, times, venues and addresses, and family message. No customer signup or checkout is needed. Easypaisa / JazzCash: 03001063545. Confirm the recipient in the payment app; verify the transfer yourself before activation.

## Run and configure
Node 24, npm 11. `npm ci`, `npm run build`, `npm start` for production; `npm run dev` for development. Configure **WEDINVITE_ADMIN_USERNAME** and a strong random **WEDINVITE_ADMIN_KEY** (the login password) securely on the server. Never commit it. `/admin` uses the username and password login. Cookies are HTTP-only, same-site, and secure in production, where HTTPS is required.

Set **WEDINVITE_DATA_DIR** to a private persistent directory outside public assets. Default: `.data` in the app root (gitignored). Back up this directory. This implementation uses an atomic local JSON store and supports a **single Node instance with persistent disk**. Do not deploy to ephemeral serverless storage or multiple replicas; migrate storage to a transactional database first. Restart with the same configured key to retain admin sign-in.

## Create and deliver
1. Sign in at `/admin`, then choose **Create invitation**.
2. Select any of the ten original designs, package and optional add-ons.
3. Enter details and up to three events. Times use Asia/Karachi.
4. Review and choose an available lowercase URL, e.g. `bilal-and-mahrukh`.
5. Save. Preview from the dashboard. Edit any saved invitation through its edit link, including activated invitations.
6. After independently verifying payment, choose **Verify payment & activate**.
7. Copy the live `/invite/{custom-url}` link or use Message customer / Share on WhatsApp. These open WhatsApp with a prepared message; they do not send automatically.
8. Guests can submit a reply through **Reply with love**; replies appear on the order card.

Activation is enforced by the invitation API. Original unpersonalized samples remain public. Duplicate custom URLs are rejected. Editing a published URL changes it immediately, so retain the original URL unless the customer requests a change.

## Scope and fulfillment
Packages follow the supplied current offer: Basic Rs. 4,999, Premium Rs. 7,999, Full Rs. 11,999. Add-ons: image Rs. 300, video Rs. 500, event pack Rs. 3,000. Template eligibility is confirmed by the studio; all ten designs are available in the editor. Full/add-on image/video packs are manually produced and sent by the studio on WhatsApp; this app does not render MP4s or dispatch WhatsApp messages automatically. There is no automatic payment gateway or bank verification.

The ten original templates retain their gestures, art and media. The server adapts event data, calendars, countdown and reveal date, and couple names. Dates and maps use submitted details; decorative sample prose and art remain part of each design. English/Urdu controls are retained; event fields are shown in the language the studio enters them.

## Validation
Production build includes TypeScript. Browser/API smoke checks cover all ten product pages, personalization, private access denial and activation. Browser check artifacts are temporary and not customer data. Existing unrelated repository lint defects were present before this work. Before public launch add durable backups, platform-level login rate limits, monitoring and deployment-specific origin configuration as appropriate.

## Local demonstration
This workspace has an ignored `.env.local` with demo login settings and ten clearly marked sample orders in `.data/platform.json`. The public sample URLs are `/invite/demo-{design}`, except private examples remain gated. Demo credentials are for local review; replace them before a public launch. Demo records do not represent real transfers or customers.

## Package fulfillment

Original prices are unchanged: One celebration Rs. 4,999 (1 event); The wedding website Rs. 7,999 (up to 3 events); The complete suite Rs. 11,999 (up to 3 events plus 2 status images, 1 status video and 3 separate event invitation images). Image/video files are prepared and delivered manually by the studio. Each package includes 2 edit requests. Delivery within 24 hours starts after complete details and payment verification.
