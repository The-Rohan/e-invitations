export const collection = [
  [
    "gulistan",
    "Gulistan",
    "A love letter from the garden",
    "Sage & rose",
    "bl",
  ],
  [
    "baradari",
    "Baradari",
    "Where forever finds its home",
    "Marble & forest",
    "baradari",
  ],
  [
    "shabistan",
    "Shabistan",
    "Written in the stars",
    "Midnight & gold",
    "shabistan",
  ],
  ["basant", "Basant", "Let your love take flight", "Marigold & sky", "basant"],
  [
    "charkha",
    "Charkha",
    "Two lives, beautifully woven",
    "Indigo & linen",
    "charkha",
  ],
  ["khat", "Khat", "Some stories deserve a letter", "Parchment & ink", "khat"],
  [
    "riwaj",
    "Riwaj",
    "A beautiful new tradition",
    "Plum & antique gold",
    "riwaj",
  ],
  [
    "androon",
    "Androon",
    "Old streets. New beginnings.",
    "Terracotta & dusk",
    "androon",
  ],
  [
    "phoolpatti",
    "Phool Patti",
    "A little colour. A lot of love.",
    "Truck art & florals",
    "phoolpatti",
  ],
  [
    "safar",
    "Safar",
    "The loveliest journey begins",
    "Teal & parchment",
    "safar",
  ],
].map(([id, name, line, palette, asset]) => ({
  id,
  name,
  line,
  palette,
  asset,
}));
export const prices = { basic: 4999, premium: 7999, full: 11999 };
export type EventInfo = {
  name: string;
  date: string;
  time: string;
  venue: string;
  address: string;
};
export type Details = {
  groom: string;
  bride: string;
  groomUr: string;
  brideUr: string;
  family: string;
  phone: string;
  events: EventInfo[];
};
export type Order = {
  id: string;
  slug?: string;
  userId: string;
  template: string;
  tier: keyof typeof prices;
  addons: string[];
  amount: number;
  details: Details;
  status: "draft" | "pending" | "approved" | "changes";
  transaction: string;
  created: string;
  note: string;
};
