# Run the WedInvite preview

1. Install Node.js 24 from https://nodejs.org/.
2. Extract this ZIP and open a terminal in the `wedinvite-preview` folder.
3. Run:

   npm ci
   npm run dev

4. When the terminal says Ready, open http://localhost:3000.
5. Admin: http://localhost:3000/admin
   Username: demo
   Password: WedInvite-Demo-2026!

Keep the terminal open while browsing. Stop the server with Ctrl+C.
If port 3000 is occupied, the terminal will show the available port to use.

The .env.local file already contains the demo settings. The archive includes
sample invitations and excludes existing signed-in sessions. These credentials
are for local preview only; replace them before publishing publicly.

Browse the ten templates, try their interactive previews, and select packages
to see their WhatsApp messages. From the admin desk, create or edit an invitation,
choose its custom URL, verify a sample payment and activate it. Payment verification
is a manual studio action; no money is collected by this preview.

This archive is the current workspace implementation. It includes the assets
used by its pages and all ten invitation designs. It does not require the
separate wedinvite repository or the archived competitor websites.

For deployment and fulfillment details, see STUDIO_OPERATIONS.md.
