"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import { SiteNav as Nav, SiteFooter as Footer } from "./Storefront";
import { collection, prices, type Details, type Order } from "@/lib/platform";
const wa = "https://wa.me/923001063545";
const money = (n: number) => "Rs. " + n.toLocaleString("en-PK");
export {
  Wordmark as Brand,
  SiteNav as Nav,
  SiteFooter as Footer,
} from "./Storefront";
async function api(body: Record<string, unknown>) {
  const r = await fetch("/api/platform", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const d = await r.json();
  if (!r.ok) throw Error(d.error);
  return d;
}
const initial: Details = {
  groom: "",
  bride: "",
  groomUr: "",
  brideUr: "",
  family: "",
  phone: "",
  events: [{ name: "Baraat", date: "", time: "19:00", venue: "", address: "" }],
};
export function Workspace({
  mode,
}: {
  mode: "studio" | "dashboard" | "admin" | "login" | "checkout";
}) {
  const [data, D] = useState<{
    user?: { email: string };
    admin?: boolean;
    orders: Order[];
    rsvps: {
      orderId: string;
      name: string;
      count: number;
      attending: boolean;
    }[];
  }>({ orders: [], rsvps: [] });
  const [step, S] = useState(0),
    [template, T] = useState("gulistan"),
    [tier, P] = useState<keyof typeof prices>("premium"),
    [details, V] = useState<Details>(initial),
    [addons, A] = useState<string[]>([]),
    [id, I] = useState(""),
    [error, E] = useState(""),
    [busy, B] = useState(false),
    [tab, Q] = useState("register"),
    [notice, N] = useState(""),
    [slug, SL] = useState(""),
    [search, Search] = useState("");
  const refresh = () =>
    fetch("/api/platform")
      .then((r) => r.json())
      .then(D);
  useEffect(() => {
    refresh();
    const p = new URLSearchParams(location.search);
    if (collection.some((t) => t.id === p.get("template")))
      T(p.get("template")!);
    if (p.get("tier") && Object.hasOwn(prices, p.get("tier")!))
      P(p.get("tier") as keyof typeof prices);
    I(p.get("order") || "");
  }, []);
  useEffect(() => {
    const edit = new URLSearchParams(location.search).get("order");
    const o = data.orders.find((o) => o.id === edit);
    if (o) {
      I(o.id);
      T(o.template);
      P(o.tier);
      V(o.details);
      A(o.addons);
      SL(o.slug || "");
    }
  }, [data.orders]);
  const act = async (body: Record<string, unknown>) => {
    B(true);
    E("");
    try {
      const result = await api(body);
      await refresh();
      return result;
    } catch (e) {
      E((e as Error).message);
    } finally {
      B(false);
    }
  };
  const total =
    prices[tier] +
    (tier === "full"
      ? 0
      : addons.reduce(
          (n, x) => n + ({ image: 300, video: 500, events: 3000 }[x] || 0),
          0,
        ));
  const field = (
    label: string,
    key: keyof Omit<Details, "events">,
    placeholder = "",
  ) => (
    <label>
      {label}
      <input
        required={["groom", "bride", "phone"].includes(key)}
        value={details[key]}
        placeholder={placeholder}
        onChange={(e) => V({ ...details, [key]: e.target.value })}
      />
    </label>
  );
  const auth = (
    <form
      className="panel auth"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        const r = await act({
          action: "admin-login",
          username: f.get("username"),
          password: f.get("password"),
        });
        if (r) N("Welcome to the studio.");
      }}
    >
      <span className="big-flower">❦</span>
      <h2>The studio desk</h2>
      <p>
        Sign in to create invitations, review payments and manage your couples.
      </p>
      <label>
        Username
        <input
          name="username"
          required
          autoComplete="username"
          placeholder="Your studio username"
        />
      </label>
      <label>
        Password
        <input
          name="password"
          type="password"
          required
          autoComplete="current-password"
        />
      </label>
      <button disabled={busy} className="button">
        {busy ? "One moment…" : "Open studio desk ↗"}
      </button>
    </form>
  );
  const order = data.orders.find((o) => o.id === id) || data.orders[0];
  return (
    <div className="platform">
      <Nav />
      <main className="workspace">
        <div className="workspace-heading">
          <div className="eyebrow">YOUR LITTLE CORNER OF FOREVER</div>
          <h1>
            {mode === "studio"
              ? "The invitation studio"
              : mode === "admin"
                ? "The studio desk"
                : mode === "checkout"
                  ? "One step closer to forever."
                  : "Your celebrations"}
          </h1>
          <p>
            {mode === "studio"
              ? "Every little detail, beautifully yours. Created by the WedInvite studio, with care."
              : "From the first little detail to the final “you’re invited”."}
          </p>
        </div>
        {error && (
          <div role="alert" className="alert">
            {error}
          </div>
        )}
        {notice && (
          <div role="status" className="alert success">
            {notice}
          </div>
        )}
        {mode === "admin" && !data.admin ? (
          auth
        ) : mode === "studio" && !data.admin ? (
          auth
        ) : mode !== "admin" && mode !== "studio" && !data.user ? (
          auth
        ) : mode === "studio" ? (
          <div className="studio-layout">
            <section className="panel">
              <div className="progress">
                {["Design", "Your story", "Celebrations", "Review"].map(
                  (s, i) => (
                    <button
                      key={s}
                      onClick={() => S(i)}
                      className={step === i ? "active" : ""}
                    >
                      {i + 1}. {s}
                    </button>
                  ),
                )}
              </div>
              <form
                onSubmit={async (e) => {
                  e.preventDefault();
                  if (step < 3) {
                    S(step + 1);
                    return;
                  }
                  const r = await act({
                    action: "save",
                    id,
                    template,
                    tier,
                    details,
                    addons,
                    slug,
                  });
                  if (r) location.href = "/admin";
                }}
              >
                {step === 0 ? (
                  <>
                    <h2>Find your feeling.</h2>
                    <div className="design-picker">
                      {collection.map((t) => (
                        <button
                          type="button"
                          className={template === t.id ? "chosen" : ""}
                          onClick={() => T(t.id)}
                          key={t.id}
                        >
                          <b>{t.name}</b>
                          <small>{t.palette}</small>
                        </button>
                      ))}
                    </div>
                    <h3>Your package</h3>
                    <div className="package-picker">
                      {Object.entries(prices).map(([k, v]) => (
                        <button
                          type="button"
                          className={tier === k ? "chosen" : ""}
                          key={k}
                          onClick={() => P(k as keyof typeof prices)}
                        >
                          {k}
                          <b>{money(v)}</b>
                        </button>
                      ))}
                    </div>
                    {tier !== "full" && (
                      <div className="addons">
                        {[
                          ["image", "WhatsApp status image", 300],
                          ["video", "WhatsApp status video", 500],
                          ["events", "Complete event pack", 3000],
                        ].map(([k, l, p]) => (
                          <label key={k}>
                            <input
                              type="checkbox"
                              checked={addons.includes(k as string)}
                              onChange={(e) =>
                                A(
                                  e.target.checked
                                    ? [...addons, k as string]
                                    : addons.filter((x) => x !== k),
                                )
                              }
                            />
                            {l} <b>+{money(p as number)}</b>
                          </label>
                        ))}
                      </div>
                    )}
                  </>
                ) : step === 1 ? (
                  <>
                    <h2>Two names. One beautiful story.</h2>
                    <div className="form-grid">
                      {field("Groom’s name", "groom", "e.g. Bilal Ahmed")}
                      {field("Bride’s name", "bride", "e.g. Mahrukh Khan")}
                      {field(
                        "Groom’s name in Urdu (optional)",
                        "groomUr",
                        "بلال",
                      )}
                      {field(
                        "Bride’s name in Urdu (optional)",
                        "brideUr",
                        "ماہ رخ",
                      )}
                      {field(
                        "Host / family message (optional)",
                        "family",
                        "Together with their families",
                      )}
                      {field("Your WhatsApp number", "phone", "03001234567")}
                    </div>
                  </>
                ) : step === 2 ? (
                  <>
                    <h2>Make room for every celebration.</h2>
                    <p>All dates and times are Pakistan local time.</p>
                    {details.events.map((ev, i) => (
                      <div className="event-form" key={i}>
                        <div className="row">
                          <h3>Celebration {i + 1}</h3>
                          {details.events.length > 1 && (
                            <button
                              type="button"
                              onClick={() =>
                                V({
                                  ...details,
                                  events: details.events.filter(
                                    (_, j) => i !== j,
                                  ),
                                })
                              }
                            >
                              Remove
                            </button>
                          )}
                        </div>
                        <div className="form-grid">
                          {(
                            [
                              "name",
                              "date",
                              "time",
                              "venue",
                              "address",
                            ] as const
                          ).map((k) => (
                            <label key={k}>
                              {
                                {
                                  name: "Event name",
                                  date: "Date",
                                  time: "Time",
                                  venue: "Venue name",
                                  address: "Venue address (optional)",
                                }[k]
                              }
                              <input
                                required={k !== "address"}
                                type={k === "date" || k === "time" ? k : "text"}
                                value={ev[k]}
                                onChange={(e) =>
                                  V({
                                    ...details,
                                    events: details.events.map((v, j) =>
                                      j === i
                                        ? { ...v, [k]: e.target.value }
                                        : v,
                                    ),
                                  })
                                }
                              />
                            </label>
                          ))}
                        </div>
                      </div>
                    ))}
                    {details.events.length < 3 && (
                      <button
                        type="button"
                        className="outline-button"
                        onClick={() =>
                          V({
                            ...details,
                            events: [
                              ...details.events,
                              {
                                name: "Walima",
                                date: "",
                                time: "19:00",
                                venue: "",
                                address: "",
                              },
                            ],
                          })
                        }
                      >
                        + Add a celebration
                      </button>
                    )}
                  </>
                ) : (
                  <>
                    <h2>A little look before the big day.</h2>
                    <div className="review">
                      <h3>
                        {details.groom || "Groom"} & {details.bride || "Bride"}
                      </h3>
                      <p>
                        {collection.find((t) => t.id === template)?.name} ·{" "}
                        {tier} package
                      </p>
                      {details.events.map((ev, i) => (
                        <p key={i}>
                          {ev.name} · {ev.date} · {ev.time}
                          <br />
                          {ev.venue}, {ev.address}
                        </p>
                      ))}
                      <label>
                        Custom invitation URL
                        <input
                          required
                          value={slug}
                          onChange={(e) =>
                            SL(
                              e.target.value
                                .toLowerCase()
                                .replace(/[^a-z0-9-]/g, ""),
                            )
                          }
                          placeholder="bilal-and-mahrukh"
                          pattern="[a-z0-9-]{3,80}"
                        />
                        <small>
                          wedinvite.pk/invite/{slug || "your-couple-name"}
                        </small>
                      </label>
                      <strong>{money(total)}</strong>
                    </div>
                    <p>
                      Your invitation stays private until we verify your
                      payment. Image and video add-ons are fulfilled by the
                      studio within 24 hours of confirmation and complete
                      details.
                    </p>
                    <label className="check">
                      <input required type="checkbox" /> I’ve checked the names,
                      dates and venues.
                    </label>
                  </>
                )}
                <div className="form-actions">
                  {step > 0 && (
                    <button
                      type="button"
                      className="outline-button"
                      onClick={() => S(step - 1)}
                    >
                      ← Back
                    </button>
                  )}
                  <button className="button" disabled={busy}>
                    {busy
                      ? "Saving…"
                      : step === 3
                        ? "Create private invitation ↗"
                        : "Next little detail →"}
                  </button>
                </div>
              </form>
            </section>
            <aside className="preview-panel">
              <div className="eyebrow">
                YOUR DESIGN · {collection.find((t) => t.id === template)?.name}
              </div>
              <iframe
                title="Interactive design sample"
                src={"/collection/card-" + template + ".html"}
              />
              <p>
                Interactive sample · your personalized preview is available
                after saving.
              </p>
              <strong>{money(total)}</strong>
              <small>One payment. A beautiful beginning.</small>
            </aside>
          </div>
        ) : mode === "checkout" ? (
          order ? (
            <div className="checkout-grid">
              <section className="panel">
                <span className="status">{order.status}</span>
                <h2>
                  A little transfer.
                  <br />A beautiful beginning.
                </h2>
                <p>
                  {order.details.groom} & {order.details.bride} ·{" "}
                  {order.template}
                </p>
                <h3>{money(order.amount)}</h3>
                <div className="payment-box">
                  <small>EASYPAISA / JAZZCASH</small>
                  <h3>0300 1063545</h3>
                  <button
                    onClick={() =>
                      navigator.clipboard
                        .writeText("03001063545")
                        .then(() => N("Payment number copied."))
                    }
                  >
                    Copy account number ↗
                  </button>
                </div>
                <p>
                  Check the recipient in your payment app before transferring.
                  Keep the receipt, then enter the transaction reference below.
                </p>
                <form
                  onSubmit={async (e) => {
                    e.preventDefault();
                    const f = new FormData(e.currentTarget);
                    const r = await act({
                      action: "submit",
                      id: order.id,
                      transaction: f.get("transaction"),
                    });
                    if (r)
                      N(
                        "Payment submitted for review. Send your receipt using the WhatsApp button below.",
                      );
                  }}
                >
                  <label>
                    Transaction reference
                    <input
                      name="transaction"
                      required
                      placeholder="Your Easypaisa / JazzCash transaction ID"
                      disabled={!["draft", "changes"].includes(order.status)}
                    />
                  </label>
                  <button
                    disabled={
                      busy || !["draft", "changes"].includes(order.status)
                    }
                    className="button"
                  >
                    Submit payment for review ↗
                  </button>
                </form>
                <a
                  className="outline-button"
                  href={
                    wa +
                    "?text=" +
                    encodeURIComponent(
                      "Assalam o Alaikum! Please verify my wedinvite.pk payment. Order: " +
                        order.id +
                        " | " +
                        order.details.groom +
                        " & " +
                        order.details.bride +
                        " | " +
                        money(order.amount) +
                        ". I will attach my payment receipt here.",
                    )
                  }
                  target="_blank"
                  rel="noreferrer"
                >
                  Send receipt on WhatsApp ↗
                </a>
                <p className="fine">
                  WhatsApp opens a prepared message. Please attach the receipt
                  yourself. Sending a message does not automatically verify
                  payment.
                </p>
              </section>
              <section className="panel">
                <h2>Your invitation, in the making.</h2>
                <iframe
                  className="checkout-preview"
                  src={"/invite/" + order.id + "?preview=1"}
                  title="Your personalized preview"
                />
                <Link className="text-link" href="/dashboard">
                  Back to your dashboard ↗
                </Link>
              </section>
            </div>
          ) : (
            <p>
              No invitation saved yet.{" "}
              <Link href="https://wa.me/923001063545?text=Assalam%20o%20Alaikum!%20I%20would%20love%20a%20wedding%20invitation.">
                Start in the studio →
              </Link>
            </p>
          )
        ) : (
          <>
            <div className="dashboard-bar">
              <p>
                {mode === "admin"
                  ? data.orders.filter((o) => o.status === "pending").length +
                    " payments waiting for your review"
                  : data.user?.email}
              </p>
              <Link className="button small" href="/admin/create">
                + Create invitation
              </Link>
              <button onClick={() => act({ action: "logout" })}>
                Sign out
              </button>
            </div>
            {mode === "admin" && (
              <>
                <div className="admin-stats">
                  <div>
                    <small>CELEBRATIONS CREATED</small>
                    <strong>{data.orders.length}</strong>
                  </div>
                  <div>
                    <small>LIVE INVITATIONS</small>
                    <strong>
                      {
                        data.orders.filter((o) => o.status === "approved")
                          .length
                      }
                    </strong>
                  </div>
                  <div>
                    <small>GUEST REPLIES</small>
                    <strong>{data.rsvps.length}</strong>
                  </div>
                </div>
                <label>
                  Find a celebration
                  <input
                    placeholder="Search couple, design or custom URL…"
                    value={search}
                    onChange={(e) => Search(e.target.value)}
                  />
                </label>
              </>
            )}
            <div className="order-grid">
              {data.orders.length === 0 && (
                <section className="panel empty">
                  <span>✉︎</span>
                  <h2>Your first little link awaits.</h2>
                  <p>Choose a design and start your wedding story.</p>
                  <Link
                    href="https://wa.me/923001063545?text=Assalam%20o%20Alaikum!%20I%20would%20love%20a%20wedding%20invitation."
                    className="button"
                  >
                    Create my invitation ↗
                  </Link>
                </section>
              )}
              {data.orders
                .filter((o) =>
                  `${o.details.groom} ${o.details.bride} ${o.slug} ${o.template}`
                    .toLowerCase()
                    .includes(search.toLowerCase()),
                )
                .map((o) => (
                  <article key={o.id} className="panel order">
                    <span className={"status " + o.status}>
                      {o.status === "approved"
                        ? "Live & lovely"
                        : o.status === "pending"
                          ? "Payment in review"
                          : o.status === "changes"
                            ? "Needs your attention"
                            : "Private draft"}
                    </span>
                    <h2>
                      {o.details.groom} <em>&</em> {o.details.bride}
                    </h2>
                    <p>
                      {o.template} · {o.tier} · {money(o.amount)}
                    </p>
                    <small>Order {o.id}</small>
                    {o.note && <p className="alert">Studio note: {o.note}</p>}
                    <div className="order-events">
                      {o.details.events.map((ev, i) => (
                        <p key={i}>
                          <b>{ev.name}</b> {ev.date} · {ev.venue}
                        </p>
                      ))}
                    </div>
                    <div className="actions">
                      <Link
                        className="outline-button"
                        href={"/invite/" + (o.slug || o.id) + "?preview=1"}
                      >
                        Preview ↗
                      </Link>
                      {o.status === "approved" ? (
                        <>
                          <button
                            className="button"
                            onClick={() =>
                              navigator.clipboard
                                .writeText(
                                  location.origin +
                                    "/invite/" +
                                    (o.slug || o.id),
                                )
                                .then(() =>
                                  N(
                                    "Invitation link copied. Ready to share with love.",
                                  ),
                                )
                            }
                          >
                            Copy live link ↗
                          </button>
                          <a
                            className="text-link"
                            href={
                              "https://wa.me/?text=" +
                              encodeURIComponent(
                                "With love, you’re invited to " +
                                  o.details.groom +
                                  " & " +
                                  o.details.bride +
                                  "’s wedding. " +
                                  (typeof location !== "undefined"
                                    ? location.origin
                                    : "") +
                                  "/invite/" +
                                  (o.slug || o.id),
                              )
                            }
                          >
                            Share on WhatsApp ↗
                          </a>
                        </>
                      ) : (
                        <span className="fine">
                          Sharing unlocks after studio activation.
                        </span>
                      )}
                    </div>
                    {mode === "admin" && (
                      <>
                        <Link
                          className="text-link"
                          href={"/admin/create?order=" + o.id}
                        >
                          Edit invitation details ↗
                        </Link>
                        <p>
                          Contact: {o.details.phone}
                          <br />
                          Transaction: {o.transaction || "Not submitted"}
                        </p>
                        {["draft", "pending", "changes"].includes(o.status) && (
                          <div className="actions">
                            <button
                              className="button"
                              onClick={() =>
                                act({ action: "approve", id: o.id })
                              }
                            >
                              Verify payment & activate
                            </button>
                            <button
                              className="outline-button"
                              onClick={() => {
                                const note = prompt(
                                  "Explain what the customer needs to correct:",
                                );
                                if (note)
                                  act({ action: "changes", id: o.id, note });
                              }}
                            >
                              Request correction
                            </button>
                          </div>
                        )}
                        <a
                          className="text-link"
                          href={
                            "https://wa.me/" +
                            o.details.phone
                              .replace(/^0/, "92")
                              .replace(/\D/g, "") +
                            "?text=" +
                            encodeURIComponent(
                              "Your wedinvite.pk order " +
                                o.id +
                                " is " +
                                o.status +
                                ". " +
                                (o.status === "approved"
                                  ? location.origin +
                                    "/invite/" +
                                    (o.slug || o.id)
                                  : ""),
                            )
                          }
                        >
                          Message customer ↗
                        </a>
                      </>
                    )}
                    {o.status === "approved" && (
                      <div>
                        <h3>Guest replies</h3>
                        {data.rsvps
                          .filter((r) => r.orderId === o.id)
                          .map((r, i) => (
                            <p key={i}>
                              {r.name} ·{" "}
                              {r.attending
                                ? r.count + " attending"
                                : "Unable to attend"}
                            </p>
                          ))}
                        {!data.rsvps.some((r) => r.orderId === o.id) && (
                          <p>
                            No replies yet. Share your invitation to get
                            started.
                          </p>
                        )}
                        <a
                          href={
                            wa +
                            "?text=" +
                            encodeURIComponent(
                              "Edit / deliverables request for order " + o.id,
                            )
                          }
                          className="text-link"
                        >
                          Request edits or package deliverables ↗
                        </a>
                      </div>
                    )}
                  </article>
                ))}
            </div>
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}
