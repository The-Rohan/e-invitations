import { NextRequest } from "next/server";
import { identity } from "@/lib/platform-server";
import fs from "node:fs";
import path from "node:path";
import { collection } from "@/lib/platform";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const { db, admin } = await identity();
  const o = db.orders.find((o) => o.id === id || o.slug === id);
  if (!o || (o.status !== "approved" && !admin))
    return new Response(
      "This invitation is private until payment is confirmed.",
      { status: 403 },
    );
  const t = collection.find((t) => t.id === o.template)!;
  const esc = (s: string) =>
    s.replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c]!,
    );
  const json = (value: unknown) =>
    JSON.stringify(value).replace(/</g, "\\u003c");
  const jsText = (value: string) =>
    json(value).slice(1, -1).replace(/'/g, "\\'");
  const names: Record<string, string> = {
    Bilal: o.details.groom,
    Mahrukh: o.details.bride,
    بلال: o.details.groomUr || o.details.groom,
    "ماہ رخ": o.details.brideUr || o.details.bride,
  };
  const replaceNames = (source: string, escape: (s: string) => string) =>
    source.replace(/Bilal|Mahrukh|بلال|ماہ رخ/g, (name) => escape(names[name]));
  const family = o.details.family || "Together with their families";
  const eventData = o.details.events.map((e, i) => {
    const d = new Date(e.date + "T" + e.time + ":00+05:00");
    const stamp = (date: Date) =>
      date.toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
    return {
      key: ["mehndi", "baraat", "walima"][i],
      name: { en: esc(e.name), ur: esc(e.name) },
      kind: { en: esc(e.name), ur: esc(e.name) },
      day: e.date.slice(8),
      mon: {
        en: d.toLocaleString("en", { month: "long", timeZone: "Asia/Karachi" }),
        ur: d.toLocaleString("ur", { month: "long", timeZone: "Asia/Karachi" }),
      },
      yr: e.date.slice(0, 4),
      wd: {
        en: d.toLocaleString("en", {
          weekday: "long",
          timeZone: "Asia/Karachi",
        }),
        ur: d.toLocaleString("ur", {
          weekday: "long",
          timeZone: "Asia/Karachi",
        }),
      },
      hr: { en: e.time, ur: e.time },
      blurb: { en: esc(family), ur: esc(family) },
      venue: { en: esc(e.venue), ur: esc(e.venue) },
      addr: { en: esc(e.address || ""), ur: esc(e.address || "") },
      q: encodeURIComponent(e.venue + " " + (e.address || "")),
      pardah: false,
      motif: "fountain",
      wear: { en: "Festive attire", ur: "روایتی لباس" },
      sw: ["#d0aa71", "#809575", "#f5eedf"],
      ics: {
        t: e.name + " — " + o.details.groom + " & " + o.details.bride,
        s: stamp(d),
        e: stamp(new Date(d.getTime() + 10800000)),
        loc: [e.venue, e.address].filter(Boolean).join(", "),
      },
    };
  });
  const first = o.details.events[0];
  const chosen = new Date(first.date + "T" + first.time + ":00+05:00");
  const place = [first.venue, first.address].filter(Boolean).join(" · ");
  const dateEn = chosen.toLocaleDateString("en-GB", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Karachi",
  });
  const dateUr = chosen.toLocaleDateString("ur-PK", {
    day: "numeric",
    month: "long",
    year: "numeric",
    timeZone: "Asia/Karachi",
  });
  const reveal = [
    { en: first.date.slice(8), ur: first.date.slice(8) },
    {
      en: chosen.toLocaleString("en", {
        month: "short",
        timeZone: "Asia/Karachi",
      }),
      ur: chosen.toLocaleString("ur", {
        month: "short",
        timeZone: "Asia/Karachi",
      }),
    },
    { en: first.date.slice(0, 4), ur: first.date.slice(0, 4) },
  ];
  // Replace sample literals before inserting user data, keeping HTML and JS escaping separate.
  const patch = (source: string) =>
    replaceNames(source, jsText)
      .replace(/var d=EVENTS\[1\];/g, "var d=EVENTS[0];")
      .replace(/EVENTS\[1\]/g, "(EVENTS[1]||EVENTS[0])")
      .replace(/EVENTS\[2\]/g, "(EVENTS[2]||EVENTS[0])")
      .replace(
        /2027-06-12T17:00:00\+05:00/g,
        first.date + "T" + first.time + ":00+05:00",
      )
      .replace(
        /var REVEAL\s*=\s*\[[^;]+;/g,
        () => "var REVEAL=" + json(reveal) + ";",
      )
      .replace(
        /num\('12'\)\+' · '\+num\('06'\)\+' · '\+num\('2027'\)/g,
        () =>
          `num(${json(first.date.slice(8))})+' · '+num(${json(first.date.slice(5, 7))})+' · '+num(${json(first.date.slice(0, 4))})`,
      )
      .replace(
        /dateSub.textContent=[^;]+;/g,
        () => "dateSub.textContent=" + json(place) + ";",
      )
      .replace(
        /var EVENTS\s*=\s*\[[\s\S]*?\n\s*\];/,
        () => "var EVENTS=" + json(eventData) + ";",
      );
  let html = fs.readFileSync(
    path.join(process.cwd(), "public/collection/card-" + t.id + ".html"),
    "utf8",
  );
  const scripts: string[] = [];
  html = html.replace(
    /<script\b([^>]*)>([\s\S]*?)<\/script>/g,
    (whole, attrs, body) => {
      const src = /src="assets\/([^"?]+\.js)(?:[^" ]*)"/.exec(attrs);
      if (src && ["card-boot.js", "card-celebration.js"].includes(src[1]))
        return whole;
      let source = body;
      if (src) {
        const file = path.join(
          process.cwd(),
          "public/collection/assets",
          src[1],
        );
        if (!fs.existsSync(file)) return whole;
        source = fs.readFileSync(file, "utf8");
      }
      scripts.push(
        "<script>" +
          patch(source).replace(/<\/script/gi, "<\\/script") +
          "</script>",
      );
      return `<!--wi-script-${scripts.length - 1}-->`;
    },
  );
  html = replaceNames(html, esc);
  const replaceText = (className: string, en: string, ur = en) => {
    const pattern = new RegExp(
      `<div class="${className}"[^>]*>[\\s\\S]*?<\\/div>`,
      "g",
    );
    html = html.replace(
      pattern,
      () =>
        `<div class="${className}" data-en="${esc(en)}" data-ur="${esc(ur)}">${esc(en)}</div>`,
    );
  };
  for (const c of ["heroDate", "heroWhen"]) replaceText(c, dateEn, dateUr);
  for (const c of ["heroPlace", "heroWhere"]) replaceText(c, place);
  replaceText("footWhen", place + " · " + dateEn, place + " · " + dateUr);
  html = html
    .replace(
      /12 June 2027|The 12th of June 2027|June 12, 2027|12 &middot; 06 &middot; 2027/g,
      () => esc(dateEn),
    )
    .replace(/۱۲ جون ۲۰۲۷/g, () => esc(dateUr))
    .replace(/Banjosa Lake(?: &middot;| ·|,) Rawalakot/g, () => esc(place))
    .replace(/بنجوسہ جھیل [·،] راولاکوٹ/g, () => esc(place))
    .replace(/From the Abbasi &amp; Kiyani families/g, () => esc(family))
    .replace(
      /<div class="fams">[\s\S]*?<\/div>\s*<\/div>/g,
      () => '<div class="fams"><p>' + esc(family) + "</p></div>",
    )
    .replace(
      /<p class="lede"[^>]*>[^<]*15 April[^<]*<\/p>/g,
      '<p class="lede" data-ur="براہِ کرم اپنی شرکت سے آگاہ کریں۔">Please let us know if you can join our celebration.</p>',
    );
  html = html.replace(
    "</head>",
    "<style>#dress,#travel,#stay,section:has(.tlFrame),section:has(.infoCards),section:has(.dressRules),section:has(#hotelArt),section:has(.clTravel),section:has(.clAttire){display:none!important}#rsvpForm{display:none!important}</style></head>",
  );
  html = html.replace("<head>", '<head><base href="/collection/">');
  html = html.replace(/<!--wi-script-(\d+)-->/g, (_, i) => scripts[Number(i)]);
  html = html.replace(
    "</body>",
    `<script>
    document.querySelectorAll('#rsvpForm').forEach(function(form){
      var button=document.createElement('button');button.type='button';button.className='btn send';button.id='studioRsvp';
      button.textContent='Reply with love ♡';button.setAttribute('data-ur','شرکت کی تصدیق کریں');
      button.addEventListener('click',function(){parent.postMessage({type:'open-rsvp'},location.origin)});
      form.before(button);
    });
    </script></body>`,
  );
  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
