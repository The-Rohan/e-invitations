import { NextRequest } from "next/server";
import { identity } from "@/lib/platform-server";
import fs from "node:fs";
import path from "node:path";
import { collection } from "@/lib/platform";
export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> },
) {
  const { id } = await params;
  const { db, user, admin } = await identity();
  const o = db.orders.find((o) => o.id === id || o.slug === id);
  if (!o || (o.status !== "approved" && o.userId !== user?.id && !admin))
    return new Response(
      "This invitation is private until payment is confirmed.",
      { status: 403 },
    );
  const t = collection.find((t) => t.id === o.template)!;
  const esc = (s: string) =>
    s.replace(
      /[&<>"']/g,
      (c) =>
        ({
          "&": "&amp;",
          "<": "&lt;",
          ">": "&gt;",
          '"': "&quot;",
          "'": "&#39;",
        })[c]!,
    );
  let html = fs.readFileSync(
    path.join(process.cwd(), "public/collection/card-" + t.id + ".html"),
    "utf8",
  );
  const eventData = o.details.events.map((e, i) => {
    const d = new Date(e.date + "T" + e.time + ":00+05:00");
    const stamp = (dt: Date) =>
      dt.toISOString().replace(/[-:]/g, "").slice(0, 15) + "Z";
    return {
      key: ["mehndi", "baraat", "walima"][i],
      name: { en: e.name, ur: e.name },
      kind: { en: e.name, ur: e.name },
      day: d.toLocaleString("en", { day: "numeric", timeZone: "Asia/Karachi" }),
      mon: {
        en: d.toLocaleString("en", { month: "long", timeZone: "Asia/Karachi" }),
        ur: d.toLocaleString("ur", { month: "long", timeZone: "Asia/Karachi" }),
      },
      yr: e.date.slice(0, 4),
      wd: {
        en: d.toLocaleString("en", {
          weekday: "long",
          timeZone: "Asia/Karachi",
        }),
        ur: "",
      },
      hr: { en: e.time, ur: e.time },
      blurb: {
        en:
          o.details.family || "Join us in celebrating our beautiful beginning.",
        ur: o.details.family || "",
      },
      venue: { en: e.venue, ur: e.venue },
      addr: { en: e.address, ur: e.address },
      q: e.venue + " " + e.address,
      pardah: false,
      motif: "fountain",
      wear: { en: "Festive attire", ur: "روایتی لباس" },
      sw: ["#d0aa71", "#809575", "#f5eedf"],
      ics: {
        t: e.name + " — " + o.details.groom + " & " + o.details.bride,
        s: stamp(d),
        e: stamp(new Date(d.getTime() + 10800000)),
        loc: e.venue + ", " + e.address,
      },
    };
  });
  const json = JSON.stringify(eventData).replace(/</g, "\\u003c");
  const first = o.details.events[0];
  const chosen = new Date(first.date + "T" + first.time + ":00+05:00");
  const reveal = JSON.stringify([
    { en: first.date.slice(8), ur: first.date.slice(8) },
    {
      en: chosen.toLocaleString("en", {
        month: "short",
        timeZone: "Asia/Karachi",
      }),
      ur: chosen.toLocaleString("ur", {
        month: "short",
        timeZone: "Asia/Karachi",
      }),
    },
    { en: first.date.slice(0, 4), ur: first.date.slice(0, 4) },
  ]);
  const patch = (s: string) =>
    s
      .replace(/EVENTS\[1\]/g, "(EVENTS[1]||EVENTS[0])")
      .replace(/EVENTS\[2\]/g, "(EVENTS[2]||EVENTS[0])")
      .replace(
        /2027-06-12T17:00:00\+05:00/g,
        first.date + "T" + first.time + ":00+05:00",
      )
      .replace(/var REVEAL\s*=\s*\[[^;]+;/g, () => "var REVEAL=" + reveal + ";")
      .replace(/num\('12'\)\+' · '\+num\('06'\)\+' · '\+num\('2027'\)/g, () =>
        JSON.stringify(first.date),
      )
      .replace(
        /var EVENTS\s*=\s*\[[\s\S]*?\n\s*\];/,
        () => "var EVENTS=" + json + ";",
      );
  html = patch(html);
  html = html.replace(
    /<script src="assets\/([^"?]+\.js)([^" ]*)"[^>]*><\/script>/g,
    (whole, file) => {
      if (["card-boot.js", "card-celebration.js"].includes(file)) return whole;
      const f = path.join(process.cwd(), "public/collection/assets", file);
      return fs.existsSync(f)
        ? "<script>" +
            patch(fs.readFileSync(f, "utf8")).replace(
              /<\/script/gi,
              "<\\/script",
            ) +
            "</script>"
        : whole;
    },
  );
  html = html
    .replace(/Bilal/g, () => esc(o.details.groom))
    .replace(/Mahrukh/g, () => esc(o.details.bride))
    .replace(/بلال/g, () => esc(o.details.groomUr || o.details.groom))
    .replace(/ماہ رخ/g, () => esc(o.details.brideUr || o.details.bride));
  html = html
    .replace(
      /12 June 2027|The 12th of June 2027|June 12, 2027|12 &middot; 06 &middot; 2027/g,
      () =>
        esc(
          chosen.toLocaleDateString("en-GB", {
            day: "numeric",
            month: "long",
            year: "numeric",
            timeZone: "Asia/Karachi",
          }),
        ),
    )
    .replace(/۱۲ جون ۲۰۲۷/g, () =>
      esc(
        chosen.toLocaleDateString("ur-PK", {
          day: "numeric",
          month: "long",
          year: "numeric",
          timeZone: "Asia/Karachi",
        }),
      ),
    );
  // Keep the original art and animation, but omit sample-only travel and schedules.
  html = html
    .replace(/Banjosa Lake(?: &middot;| ·|,) Rawalakot/g, () =>
      esc(first.venue + " · " + first.address),
    )
    .replace(/بنجوسہ جھیل [·،] راولاکوٹ/g, () =>
      esc(first.venue + " · " + first.address),
    );
  html = html.replace(
    /<div class="fams">[\s\S]*?<\/div>\s*<\/div>/,
    () =>
      '<div class="fams"><p>' +
      esc(o.details.family || "Together with their families") +
      "</p></div>",
  );
  html = html.replace(
    "</head>",
    "<style>#dress,#travel,#stay,section:has(.tlFrame),section:has(.infoCards),section:has(.dressRules){display:none!important}</style></head>",
  );
  html = html.replace("<head>", '<head><base href="/collection/">');
  html = html.replace(/<script>([\s\S]*?)<\/script>/g, (full) =>
    full.replace(/12 June 2027/g, o.details.events[0].date),
  );
  html = html.replace(
    "</body>",
    '<script>document.querySelectorAll("#rsvpForm").forEach(function(f){f.addEventListener("submit",function(e){e.preventDefault();e.stopImmediatePropagation();parent.postMessage({type:"open-rsvp"},location.origin);},true)});</script></body>',
  );
  return new Response(html, {
    headers: {
      "Content-Type": "text/html; charset=utf-8",
      "Cache-Control": "private, no-store",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
