import { NextRequest, NextResponse } from "next/server";
import { identity, writeDB, token, hash, equal } from "@/lib/platform-server";
import { collection, prices, type Details, type Order } from "@/lib/platform";
const loginAttempts = new Map<string, { count: number; until: number }>();
export async function GET() {
  const { db, user, admin } = await identity();
  return NextResponse.json({
    user: user ? { email: user.email } : null,
    admin,
    orders: admin
      ? db.orders
      : user
        ? db.orders.filter((o) => o.userId === (user?.id || "studio"))
        : [],
    rsvps: db.rsvps.filter(
      (r) =>
        admin ||
        db.orders.some((o) => o.id === r.orderId && o.userId === user?.id),
    ),
  });
}
export async function POST(req: NextRequest) {
  if (
    !req.headers.get("origin") ||
    new URL(req.headers.get("origin")!).host !== req.headers.get("host")
  )
    return NextResponse.json({ error: "Invalid origin" }, { status: 403 });
  try {
    const b = await req.json();
    const { db, user, admin } = await identity();
    const c = (await import("next/headers")).cookies;
    const jar = await c();
    const fail = (error: string, status = 400) =>
      NextResponse.json({ error }, { status });
    if (b.action === "logout") {
      jar.delete("wi-session");
      jar.delete("wi-admin");
      return NextResponse.json({ ok: true });
    }
    if (b.action === "admin-login") {
      if (!process.env.WEDINVITE_ADMIN_KEY)
        return fail(
          "Admin access must be configured with WEDINVITE_ADMIN_KEY on the server.",
          503,
        );
      const ip = req.headers.get("x-forwarded-for")?.split(",")[0] || "local";
      const previous = loginAttempts.get(ip);
      const attempts =
        previous && previous.until > Date.now()
          ? previous
          : { count: 0, until: Date.now() + 900000 };
      if (attempts.count >= 10)
        return fail("Too many attempts. Please try again in 15 minutes.", 429);
      attempts.count++;
      loginAttempts.set(ip, attempts);
      if (loginAttempts.size > 10000) loginAttempts.clear();
      if (
        (process.env.WEDINVITE_ADMIN_USERNAME &&
          !equal(
            String(b.username || ""),
            process.env.WEDINVITE_ADMIN_USERNAME,
          )) ||
        !equal(
          String(b.password || b.key || ""),
          process.env.WEDINVITE_ADMIN_KEY,
        )
      )
        return fail("Username or password is incorrect", 401);
      loginAttempts.delete(ip);
      const adminToken = token();
      db.sessions = db.sessions.filter((s) => s.expires > Date.now());
      db.sessions.push({
        token: hash(adminToken),
        userId: "admin",
        expires: Date.now() + 28800000,
      });
      writeDB(db);
      jar.set("wi-admin", adminToken, {
        httpOnly: true,
        sameSite: "strict",
        secure: process.env.NODE_ENV === "production",
        maxAge: 28800,
        path: "/",
      });
      return NextResponse.json({ ok: true });
    }
    if (b.action === "register" || b.action === "login")
      return fail(
        "Customer accounts are not used. Please contact the studio on WhatsApp.",
        403,
      );
    if (b.action === "rsvp") {
      const o = db.orders.find(
        (o) => (o.id === b.id || o.slug === b.id) && o.status === "approved",
      );
      if (!o) return fail("Invitation unavailable", 404);
      if (
        !String(b.name || "").trim() ||
        !Number.isInteger(b.count) ||
        b.count < 1 ||
        b.count > 20
      )
        return fail("Enter your name and 1–20 guests.");
      db.rsvps.push({
        orderId: o.id,
        name: String(b.name).slice(0, 100),
        count: b.count,
        attending: !!b.attending,
      });
      writeDB(db);
      return NextResponse.json({ ok: true });
    }
    if (b.action === "approve" || b.action === "changes") {
      if (!admin) return fail("Admin sign-in required", 403);
      const o = db.orders.find((o) => o.id === b.id);
      if (!o) return fail("Order not found", 404);
      if (!["draft", "pending", "changes"].includes(o.status))
        return fail("Only submitted orders can be reviewed");
      o.status = b.action === "approve" ? "approved" : "changes";
      o.note = String(b.note || "").slice(0, 1000);
      writeDB(db);
      return NextResponse.json({ ok: true });
    }
    if (!admin) return fail("Admin sign-in required.", 403);
    if (b.action === "save") {
      if (
        !collection.some((t) => t.id === b.template) ||
        !Object.hasOwn(prices, b.tier)
      )
        return fail("Choose a valid template and package");
      const d = b.details as Details;
      if (
        !d ||
        !d.groom?.trim() ||
        !d.bride?.trim() ||
        !/^\+?[\d\s-]{10,16}$/.test(d.phone) ||
        !Array.isArray(d.events) ||
        d.events.length < 1 ||
        d.events.length > 3 ||
        d.events.some(
          (e) =>
            !e.name ||
            !/^\d{4}-\d{2}-\d{2}$/.test(e.date) ||
            !/^([01]\d|2[0-3]):[0-5]\d$/.test(e.time) ||
            !Number.isFinite(Date.parse(e.date + "T" + e.time + ":00+05:00")) ||
            !e.venue,
        )
      )
        return fail("Complete the couple, WhatsApp and event details.");
      let o = db.orders.find(
        (o) => o.id === b.id && o.userId === (user?.id || "studio"),
      );
      if (o && !admin && o.status !== "draft" && o.status !== "changes")
        return fail(
          "Submitted invitations are locked. Request corrections through support.",
        );
      const addons = (b.addons || []).filter((x: string) =>
        ["image", "video", "events"].includes(x),
      );
      const tier = b.tier as keyof typeof prices;
      const amount =
        prices[tier] +
        (tier === "full"
          ? 0
          : [...new Set<string>(addons)].reduce(
              (n, x) => n + ({ image: 300, video: 500, events: 3000 }[x] || 0),
              0,
            ));
      const slug = String(b.slug || "");
      if (!/^[a-z0-9-]{3,80}$/.test(slug))
        return fail(
          "Use 3–80 lowercase letters, numbers or hyphens for the URL.",
        );
      if (db.orders.some((x) => x.slug === slug && x.id !== o?.id))
        return fail("This invitation URL is already taken.");
      if (!o) {
        o = {
          slug,
          id: token(),
          userId: user?.id || "studio",
          template: b.template,
          tier,
          addons,
          amount,
          details: d,
          status: "draft",
          transaction: "",
          created: new Date().toISOString(),
          note: "",
        };
        db.orders.push(o);
      } else
        Object.assign(o, {
          slug,
          template: b.template,
          tier,
          addons,
          amount,
          details: d,
        });
      writeDB(db);
      return NextResponse.json({ ok: true, id: o.id });
    }
    if (b.action === "submit") {
      const o = db.orders.find(
        (o) => o.id === b.id && o.userId === (user?.id || "studio"),
      );
      if (!o || !["draft", "changes"].includes(o.status))
        return fail("Order cannot be submitted");
      if (!String(b.transaction || "").trim())
        return fail("Please enter your payment transaction reference.");
      o.transaction = String(b.transaction).slice(0, 150);
      o.status = "pending";
      writeDB(db);
      return NextResponse.json({ ok: true });
    }
    return fail("Unknown action");
  } catch {
    return NextResponse.json(
      { error: "Unable to process this request." },
      { status: 400 },
    );
  }
}
