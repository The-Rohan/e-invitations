import { Suspense } from "react";
import Invitation from "@/components/Invitation";
async function Content({ params }: { params: Promise<{ id: string }> }) {
  return <Invitation id={(await params).id} />;
}

export default function Page(props: { params: Promise<{ id: string }> }) {
  return (
    <Suspense fallback={<div>Preparing something lovely…</div>}>
      <Content {...props} />
    </Suspense>
  );
}
