import {Workspace} from '@/components/Platform';
export default function Page(){return <Workspace mode="admin"/>}
