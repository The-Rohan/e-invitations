import {CollectionPage} from '@/components/Storefront';
export default CollectionPage;
