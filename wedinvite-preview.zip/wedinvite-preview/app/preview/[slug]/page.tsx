import { Suspense } from "react";
import { collection } from "@/lib/platform";
import { notFound } from "next/navigation";
import Link from "next/link";
async function Content({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  if (!collection.some((t) => t.id === slug)) notFound();
  return (
    <div className="invitation">
      <iframe
        title="Interactive invitation sample"
        src={"/collection/card-" + slug + ".html"}
      />
      <Link className="rsvp-float" href={"/studio?template=" + slug}>
        Make this your story ↗
      </Link>
    </div>
  );
}

export default function Page(props: { params: Promise<{ slug: string }> }) {
  return (
    <Suspense fallback={<div>Preparing something lovely…</div>}>
      <Content {...props} />
    </Suspense>
  );
}
