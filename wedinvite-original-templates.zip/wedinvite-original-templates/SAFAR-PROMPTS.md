# Safar — Prompt Deck (template 10, after Phool Patti)

A railway wedding: steam, brass and golden hour. Built card: `card-safar.html`
+ `safar.html` (split-card base). Assets in `assets/safar/`. The suite's first
**light cream + teal ink** palette since Basant.

Source media: `C:\Users\deskt\Downloads\ioasia` (1930s railway travel poster
style — flat screen-printed gouache, cream print borders, halftone grain).

## Palette (locked — matches safar.css `:root`)

```
--paper:#F3E6CE   (aged cream paper)
--paper-2:#F9EFD9 --panel:#EFE2C4 --linen:#FAF4E3
--ink:#1E3038     (deep teal ink)
--ink-2:#3C4E56   --muted:#8A7A64 --faint:#C4B28E
--accent:#C0954E  (brass)
--art:#6B1F26     (oxblood)
--line:#E0D0A8
Desktop stage: deep oxblood #2A1418
```

## Asset map (all wired, JPGs kept — poster borders blend on cream)

| slot | source plate |
|---|---|
| `hero.jpg` | steam locomotive 3/4 at platform, golden hour (portrait) |
| `gate.mp4` / `gate-poster.jpg` | the arrival film — see spec |
| `venue.jpg` | colonial station facade, blank board, marigold columns |
| `dress.jpg` | open leather trunk on the bench, engine behind |
| `ev-mehndi.jpg` | platform tea stall (samovar, henna, dholak) |
| `ev-baraat.jpg` | garlanded locomotive, bells + bunting |
| `ev-walima.jpg` | farewell feast on the platform |
| `tlframe.jpg` | station clock with garland (timeline plate) |
| `motif-train / clock / ticket / signal / lamp.jpg` | motif set on cream tiles |
| `og.jpg` | hero @1200w |

## Film spec

720×1280 at 8.00 s, muted CRF 26 (**1.09 MB**), poster = first frame.
`HANDOFF=7.5` — the film *is* the arrival: empty platform → steam burst → the
train pulls in and lands front-on. SSIM vs hero plateaus ~0.4 (compositions
differ by design), so the handoff is the narrative one — the train has arrived.

## Copy hooks

Venues: **Mehndi Junction → Platform Two → Walima Terminus** (Safar Station,
Walled City, Lahore). Reveal = **hold each ticket stub — "the date is punched
through"** (dashed-border stub tiles). Copy: "all aboard", "the whistle sounds
just before eight". Urdu strings in `card-safar.html` + the EVENTS table in
`assets/safar/safar.js`.

## Shared style suffix (what produced this set)

> …in the style of a vintage 1930s railway travel poster: flat screen-printed
> gouache, limited palette of oxblood red, brass gold, warm cream and deep teal,
> subtle paper grain and halftone texture, bold simple shapes with elegant
> linework, warm lamplight, thin cream poster border. No text, no lettering,
> no numbers.
