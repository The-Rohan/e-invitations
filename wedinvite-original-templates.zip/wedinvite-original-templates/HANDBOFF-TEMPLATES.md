# wedinvite — Template Suite Handoff
**For: next developer / AI agent** · 10 production-ready wedding invitation templates
· Last updated: 7 Nov 2026

---

## 0 · READ THIS FIRST — Integration Instructions

You are receiving **10 finished, self-contained wedding invitation templates**. Each
one is a complete product: demo page + guest-facing card + art + bilingual copy +
film. Your job is to integrate them into the production site. Work **in this order**:

### A. How each template is built (architecture — do not break it)

```
<name>.html            → marketing demo shell (iPhone mockup + "Make it Yours" CTA)
card-<name>.html       → the actual invitation a guest receives (loads in the shell's iframe)
assets/<name>/         → <name>.css, <name>.js, fonts/, art, gate.mp4 + gate-poster.jpg
assets/card-boot.js    → SHARED boot: iOS Low-Power-Mode video fix. Every card calls NiruBoot.run()/NiruBoot.play()
assets/card-celebration.js → SHARED: NiruCelebrate() petal shower + NiruAutoScroll
assets/music.mp3       → SHARED bgm track (2:44). Do NOT add per-template tracks.
```

Rules that hold across **all** templates:
- Mobile (<760px): the card fills the screen, no phone chrome. Desktop: the card renders
  at a fixed **402 px** base width, scaled with `transform:scale()` inside the mockup
  (`BASE = 402` in each shell's script). Keep this number in sync everywhere.
- The "Make it Yours" / "Get now" CTA links to `order?tpl=<name>` — **wire these to
  your checkout/product pages** (currently relative dead links).
- Bilingual EN/اردو: every string carries `data-ur` (and `data-ur-ph` for placeholders);
  language + text-size persist in `localStorage` under keys `<name>-lang` and `<name>-tsz`.
- Gate film: muted, autoplay-on-tap via `NiruBoot.play()`; `HANDOFF` (seconds) in each
  template's JS switches from film to hero. If you ever re-render a film, re-measure
  HANDOFF (see TEMPLATE_SPEC.md §ffmpeg). The film must **never block the guest** —
  playback errors fall through to the hero automatically.
- Reveal interaction: every template has one (see table) that unlocks the date +
  triggers `NiruCelebrate` petals. All are pointer-based with reduced-motion fallbacks.
- RSVP form: posts `FormData` (fields: `card`, `name`, per-event `att_<key>`,
  `guests_<key>`, `message`) to `RSVP_ENDPOINT` — **currently empty string** in every
  `assets/<name>/<name>.js`. Wire it to your backend; the hidden `card` field
  identifies the template (Gulistan's is the legacy id **`bellagio`**).

### B. Production integration checklist (do these once)

1. **Personalization.** Couple names, venues, dates and blurb copy are **hardcoded**
   in two places per template: the EVENTS table at the top of `assets/<name>/<name>.js`
   and section markup in `card-<name>.html`. To sell personalized cards you must add a
   build/templating step (e.g. a JSON config → string-replace, or dynamic injection)
   before generating a customer's card. The EVENTS table is the single source for the
   three event cards, RSVP blocks, calendar links (gcal + .ics) and countdown target
   (`new Date('2027-06-12T17:00:00+05:00')` in each JS — update per order).
2. **RSVP backend.** Set `RSVP_ENDPOINT` in each template's JS. The form is
   `novalidate` + fake-submit until then. Send `card` id with every row.
3. **Order flow.** Replace every `order?tpl=<name>` href with your real product URLs.
4. **Hosting.** Serve over **http(s)** — `file://` blocks the self-hosted webfonts
   (CORS) and text falls back to system serif. Bump the `?v=` query on
   `card-<name>.html` iframe src + CSS/JS links whenever you redeploy a template.
5. **OG/social.** Each shell has its own `og.jpg` (in `assets/<name>/`); shell OG
   tags point to `./assets/<name>/og.jpg`. Keep og:image 1200×630-ish when replacing.
6. **Known pending fixes** (do these during integration):
   - `assets/androon/gate.mp4` is 3.97 MB (target ≤3 MB): recompress to CRF 26–27.
   - `assets/androon/` motifs (cypress/diya/dholak/lotus PNGs) are inherited from
     Riwaj and show opaque black plates — regenerate as sepia-on-cream line art.
   - Stale per-template copies of `music.mp3` exist in `assets/baradari/` and
     `assets/bl/` — harmless but wasteful; the referenced track is `assets/music.mp3`.
   - `TEMPLATE_SPEC.md` documents templates 1–4 only; this file supersedes it for
     templates 5–10.

### C. Adding template #11 (if you extend the suite)

Follow TEMPLATE_SPEC.md + the newest pattern (Safar is the cleanest example):
copy `card-safar.html` → `card-<name>.html`, create `assets/<name>/` with fonts
(copied from any template) + art + film, write `<name>.css` (retheme via `:root`
variables only), `<name>.js` (update EVENTS table, HANDOFF, petal colors), and a
`<name>.html` shell. Prompt decks used per template: `BELLAGIO-PROMPTS.md` (Gulistan),
`ANDROON-PROMPTS.md`, `PHOOLPATTI-PROMPTS.md`, `SAFAR-PROMPTS.md` — follow their
"shared style suffix" pattern so all art in a template stays in one visual hand.

---

## 1 · The 10 templates — sorted (chronological build order)

| # | Template | Theme | Tone | Shell | Card | JS/CSS | Gate film | HANDOFF |
|---|---|---|---|---|---|---|---|---|
| 1 | **Baradari** | Marble garden pavilion — the reference implementation | Light forest-green | `baradari.html` | `card-baradari.html` | `assets/baradari/baradari.{js,css}` | 2.87 MB | 6.35 |
| 2 | **Gulistan** | Rose garden — the flagship (demo = `index.html`) | Light cream + woven linen | `index.html` | `card-gulistan.html` | inline in card | intro film (intro-opt.mp4) | 7.5 |
| 3 | **Shabistan** | Night courtyard, gold screen-blend motifs | **Dark** navy + gold | `shabistan.html` | `card-shabistan.html` | `assets/shabistan/shabistan.{js,css}` | 2.38 MB | 7.55 |
| 4 | **Basant** | Rooftop kite festival | Light daytime | `basant.html` | `card-basant.html` | `assets/basant/basant.{js,css}` | 2.21 MB | 7.55 |
| 5 | **Charkha** | Heritage spinning wheel (textile) | Light indigo | `charkha.html` | `card-charkha.html` | `assets/charkha/charkha.{js,css}` | 2.94 MB | 7.55 |
| 6 | **Khat** | Hand-written letter, wax seal | Soft paper | `khat.html` | `card-khat.html` | `assets/khat/khat.{js,css}` | 1.63 MB | 8.9 |
| 7 | **Riwaj** | Plum-ink heritage | Light plum | `riwaj.html` | `card-riwaj.html` | `assets/riwaj/riwaj.{js,css}` | 1.52 MB | 8.35 |
| 8 | **Androon** | Old walled city at dusk | Warm sepia + amber | `androon.html` | `card-androon.html` | `assets/androon/androon.{js,css}` | 3.97 MB ⚠ | 7.6 |
| 9 | **Phool Patti** | Pakistani truck art | **Matte black + neon folk** | `phoolpatti.html` | `card-phoolpatti.html` | `assets/phoolpatti/phoolpatti.{js,css}` | 2.31 MB (boomerang) | 11.2 |
| 10 | **Safar** | Steam-train railway journey | Cream + teal + oxblood | `safar.html` | `card-safar.html` | `assets/safar/safar.{js,css}` | 1.09 MB | 7.5 |

Palettes (key vars from each `<name>.css :root`):
- **Baradari** `--paper:#F3EADA --forest:#1E3B2F --gold:#C3A35B`
- **Gulistan** `--paper:#F1E7D3 --script-ink:#222E24 --sage:#7D8B6E --gold:#B0A075` (woven-linen fallback)
- **Shabistan** `--paper:#12213A --forest:#0A0F1D --gold:#C9A25E` (dark pilot)
- **Basant** `--paper:#F8F4EA --forest:#1F3A44 --sand:#D9863B --kaghazi:#E9B44C`
- **Charkha** `--paper:#F3EAD8 --forest:#1F2E4D --gold:#C98E3E`
- **Khat** `--paper:#F6F1E7 --forest:#2B2F33 --gold:#B79A5B`
- **Riwaj** `--paper:#F5EFE4 --ink:#3D2B33 --accent:#C08A3E --art:#8A3B4A`
- **Androon** `--paper:#F5EBD8 --ink:#3E2A20 --accent:#D98E2B --art:#C1632E`
- **Phool Patti** `--paper:#1B1512 --ink:#F7EEDD (inverted) --accent:#F2A63B --art:#E85D9E`
- **Safar** `--paper:#F3E6CE --ink:#1E3038 --accent:#C0954E --art:#6B1F26`

## 2 · Reveal mechanics (one per template — the signature interaction)

| Template | Mechanic | Where in code |
|---|---|---|
| Baradari | Drag the brass **key** to the lock (pointer events, 72px drop radius, tap = unlock) | `keyTag`/`keyHint` in baradari.js |
| Gulistan | (follows Baradari pattern; card is inline-styled) | in card-gulistan.html |
| Shabistan | Tap **3 lanterns** until all lit → `unlockDate()` | `.lanternBtn` loop in shabistan.js |
| Basant | Lift **3 kites** (same code, renamed) | `.kiteBtn` row in basant.js |
| Charkha | **Grab the wheel and turn it clockwise** (drag rotation) | charkha.js (`Grab the wheel…` STR) |
| Khat | Press-and-hold the **wax seal** | khat.js (`Press and hold the wax seal`) |
| Riwaj | Hold **3 wax seals** ~0.8 s each (`--wax` 0..1) | `.sealTile` + HOLD timer in riwaj.js |
| Androon | Same seal-hold ×3 (renamed copy) | `.sealTile` in androon.js |
| Phool Patti | Hold **3 bells** — "the date rings out" | `.sealTile` in phoolpatti.js |
| Safar | Hold **3 ticket stubs** — "the date is punched through" (dashed perforation tiles) | `.sealTile` in safar.js |

## 3 · Demo shells & order links

- Shells: `index.html` (Gulistan flagship), `baradari.html`, `shabistan.html`,
  `basant.html`, `charkhat…` → full list: `androon.html baradari.html basant.html
  charkha.html index.html khat.html phoolpatti.html riwaj.html safar.html shabistan.html`
- Every shell CTA → `order?tpl=<name>` (Gulistan uses `order?tpl=gulistan`; its card
  posts RSVP with legacy id `bellagio` — keep both consistent in your backend).
- Shell behaviors to preserve: BASE=402 scale, `.demo-book` appears after ~80% scroll
  or 25 s, `?v=` cache-bust, `niru:map-open`/`niru:map-close` postMessage guard.

## 4 · Reference docs in this folder

- `TEMPLATE_SPEC.md` — full build rules (templates 1–4 era; still authoritative for
  the two-layer architecture, film pipeline, mobile rules, bilingual system).
- `BELLAGIO-PROMPTS.md` (referenced by Gulistan, not in folder), `ANDROON-PROMPTS.md`,
  `PHOOLPATTI-PROMPTS.md`, `SAFAR-PROMPTS.md` — art-direction prompt decks.
- `screenshots/` — QA screenshots from the builds.

## 5 · Fonts

Self-hosted per template in `assets/<name>/fonts/`: Playfair Display italic 600
(display), Lora var (body), Jost var (caps), + Arabic (Amiri stack) / Urdu
(Noto Nastaliq stack, system fallback). Baradari-era templates ship
Marcellus/Italianno/Lora/Jost. Don't hotlink Google Fonts; copy the woff2 set.
