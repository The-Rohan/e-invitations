# Phool Patti — Prompt Deck (template 9, after Androon)

Jingle-truck maximalism on a matte-black tailgate. The suite's first loud, first
dark-reverse card. Built: `phoolpatti.html` + `card-phoolpatti.html` (from the
Androon split-card pattern). Assets in `assets/phoolpatti/`.

Source media: `C:\Users\deskt\Downloads\new twmplate` (12 files, flat folk-vector
style — the deck's original "acrylic painted" suffix came back as clean vector
folk art; keep regen requests in that hand).

## Palette (locked — matches phoolpatti.css `:root`)

```
--paper:#1B1512   (matte tailgate black-brown; cream ink inverted)
--paper-2:#241B14 --panel:#241B14 --linen:#2B211A
--ink:#F7EEDD --ink-2:#D9C6A6 --muted:#A8967C --faint:#6E5F4C
--accent:#F2A63B  (marigold chrome)
--art:#E85D9E     (rani pink)
--line:#3E3126
Shell stage: sunset-red plum (#4A1F22 → #141010)
```

## Shared style suffix (what actually produced this set)

> …in Pakistani truck-art (phool patti) style: clean flat folk vector
> illustration with bold dark outlines and white highlight lines, saturated folk
> colors on a matte black ground, symmetrical composition, dense decorative
> borders, scalloped chrome forms, brass bells, mirror tinsel, peacocks with
> heart-shaped tail feathers, marigold and jasmine strings. No text, no
> lettering, no signature.

## Asset map (all wired)

| asset | source plate | notes |
|---|---|---|
| `hero.jpg` | Truck tailgate (portrait) | gate handoff still |
| `venue.jpg` | Folk arch (landscape, white page) | displays as a painted plate inset |
| `dress.jpg` | Grille closeup (landscape) | dress code art |
| `tlframe.jpg` | Dhol-drum frame (landscape, white page) | `.tlArt` plate; rows flow below (window was too narrow for text) |
| `ev-mehndi.jpg` | Event board w/ empty center | above the Mehndi plaque |
| `ev-baraat.jpg` | Dhol drum w/ garland | above the Baraat plaque |
| `ev-walima.jpg` | Street feast valance | above the Walima plaque |
| `motif-peacock.jpg` etc. | peacock/corner/bell/mirror/dhol | cream plate tiles (`.motif` bg `--linen`) |
| `gate.mp4` + poster | Folk_art_truck_tailgate.mp4 | see film spec |
| `og.jpg` | hero @1200w | share card |

## Film spec

**Boomerang** (the source zooms *into* the paintwork, so forward-then-reverse):
fwd 5.9 s + reversed tail = 11.83 s, 720×1280, muted, CRF 27, faststart,
**2.31 MB** ✓ under target. Poster = first frame (wide tailgate = hero comp).
`HANDOFF=11.2` — SSIM dives to ~0.12 mid-film and climbs to ~0.82 on the
way out.

## Copy hooks

MASHAALLAH over the arch (HTML), "follow the horns" transport line,
"Wear your brightest" dress sub, venues: painted courtyard / Phool Patti
Chowk / Truck Adda (Kucha Phool Patti, Walled City, Lahore). Reveal =
hold each bell, "the date rings out".
