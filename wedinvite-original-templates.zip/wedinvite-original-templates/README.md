# wedinvite — 10 Production-Ready Wedding Invitation Templates

A suite of 10 digital wedding invitation templates for **wedinvite**, featuring rich cultural aesthetics, bilingual typography (English & Urdu), custom reveal interactions, responsive mobile-first invitation cards, and desktop iPhone mockups.

---

## 🎨 The 10 Templates Suite

| # | Template | Theme & Atmosphere | Visual Palette | Reveal Interaction | Shell Demo | Direct Card |
|---|---|---|---|---|---|---|
| **1** | **Baradari** | Marble garden pavilion & arches | Forest Green, Cream & Gold | Brass key drag-to-unlock | [`baradari.html`](./baradari.html) | [`card-baradari.html`](./card-baradari.html) |
| **2** | **Gulistan** | Rose garden & woven linen (Flagship) | Soft Cream, Sage & Muted Gold | Drag key / tap to reveal date | [`index.html`](./index.html) | [`card-gulistan.html`](./card-gulistan.html) |
| **3** | **Shabistan** | Night courtyard & celestial skies | Deep Navy Midnight & Radiant Gold | Tap 3 lanterns to illuminate | [`shabistan.html`](./shabistan.html) | [`card-shabistan.html`](./card-shabistan.html) |
| **4** | **Basant** | Spring rooftop kite festival | Kaghazi Yellow, Amber & Sky Slate | Lift 3 kites into flight | [`basant.html`](./basant.html) | [`card-basant.html`](./card-basant.html) |
| **5** | **Charkha** | Heritage loom & craft textiles | Indigo Loom & Raw Sand | Rotate the spinning wheel clockwise | [`charkha.html`](./charkha.html) | [`card-charkha.html`](./card-charkha.html) |
| **6** | **Khat** | Vintage epistolary parchment & wax seal | Soft Stationery Paper & Ink | Press-and-hold royal wax seal | [`khat.html`](./khat.html) | [`card-khat.html`](./card-khat.html) |
| **7** | **Riwaj** | Heritage plum velvet & antique gold | Deep Plum & Vintage Gold | Press & hold 3 heirloom seals | [`riwaj.html`](./riwaj.html) | [`card-riwaj.html`](./card-riwaj.html) |
| **8** | **Androon** | Walled city at dusk (heritage brick & terracotta) | Warm Sepia, Terracotta & Amber | Press & hold 3 gateway seals | [`androon.html`](./androon.html) | [`card-androon.html`](./card-androon.html) |
| **9** | **Phool Patti** | Vibrant Pakistani truck art & floral enamel | Matte Black, Neon Pink, Amber & Enamel | Hold 3 ghungroo bells to ring | [`phoolpatti.html`](./phoolpatti.html) | [`card-phoolpatti.html`](./card-phoolpatti.html) |
| **10** | **Safar** | Heritage steam railway journey | Parchment, Locomotive Teal & Oxblood | Press & hold 3 railway ticket stubs | [`safar.html`](./safar.html) | [`card-safar.html`](./card-safar.html) |

---

## 🏛 Architecture & Engineering

Each template is structured into two clean layers:
1. **Marketing Demo Shell (`<name>.html`)**:
   - Renders a responsive iPhone 16 Pro mockup (`assets/iphone-mockup-20260921.webp`) on desktop viewports.
   - Embeds the actual guest card inside a responsive `iframe` scaled via CSS transforms (`BASE = 402px`).
   - Floats a dynamic "Make it Yours" / "Get Now" CTA bar (`order?tpl=<name>`).
2. **Guest Invitation Card (`card-<name>.html`)**:
   - Fullscreen viewport on mobile devices (<760px).
   - Cinematic entry video (`assets/<name>/gate.mp4`) with smooth handoff timing (`HANDOFF` seconds).
   - Powered by `assets/card-boot.js` (`NiruBoot`) to handle iOS Low-Power Mode video policies seamlessly.
   - Interactive reveal mechanism unlocking the event dates, triggering celebratory flower petal showers via `assets/card-celebration.js` (`NiruCelebrate`).
   - Multilingual toggle: English and Urdu (`data-ur` and `data-ur-ph` attributes), with text size customization saved to `localStorage`.
   - Countdown timer, 3-event agenda (e.g., Mehndi, Baraat, Walima), Google Calendar / .ics exports, venue map links, and RSVP form.

---

## 🚀 Local Quickstart

Because self-hosted fonts (`.woff2`) and video assets use CORS security policies, serve the project over HTTP rather than `file://`:

```bash
# Python 3 built-in HTTP server
python3 -m http.server 8000

# Open in browser:
# Gulistan (Flagship): http://localhost:8000/
# Baradari:           http://localhost:8000/baradari.html
# Shabistan:          http://localhost:8000/shabistan.html
# Basant:             http://localhost:8000/basant.html
# Charkha:            http://localhost:8000/charkha.html
# Khat:               http://localhost:8000/khat.html
# Riwaj:              http://localhost:8000/riwaj.html
# Androon:            http://localhost:8000/androon.html
# Phool Patti:        http://localhost:8000/phoolpatti.html
# Safar:              http://localhost:8000/safar.html
```

---

## 📁 Repository Structure

```
├── index.html                   # Gulistan marketing shell (root)
├── card-gulistan.html           # Gulistan card invitation
├── baradari.html                # Baradari marketing shell
├── card-baradari.html           # Baradari card invitation
├── shabistan.html               # Shabistan marketing shell
├── card-shabistan.html          # Shabistan card invitation
├── basant.html                  # Basant marketing shell
├── card-basant.html             # Basant card invitation
├── charkha.html                 # Charkha marketing shell
├── card-charkha.html            # Charkha card invitation
├── khat.html                    # Khat marketing shell
├── card-khat.html               # Khat card invitation
├── riwaj.html                   # Riwaj marketing shell
├── card-riwaj.html              # Riwaj card invitation
├── androon.html                 # Androon marketing shell
├── card-androon.html            # Androon card invitation
├── phoolpatti.html              # Phool Patti marketing shell
├── card-phoolpatti.html         # Phool Patti card invitation
├── safar.html                   # Safar marketing shell
├── card-safar.html              # Safar card invitation
├── assets/                      # Shared & template-specific assets
│   ├── card-boot.js             # iOS Low-Power Mode video fix
│   ├── card-celebration.js      # Confetti / petal shower engine
│   ├── music.mp3                # Shared background track
│   ├── fonts/                   # Self-hosted typography (woff2)
│   └── <name>/                  # CSS, JS, artwork, gate.mp4 for each template
├── screenshots/                 # Complete QA screenshots archive (64 images)
├── HANDBOFF-TEMPLATES.md        # Comprehensive integration and design handoff guide
├── TEMPLATE_SPEC.md             # Technical specification and architectural guidelines
└── *-PROMPTS.md                 # Generative art direction prompt decks
```

---

## 📜 Documentation & Integration Guides

- **[`HANDBOFF-TEMPLATES.md`](./HANDBOFF-TEMPLATES.md)**: Full developer handoff detailing EVENTS table schema, RSVP endpoints, order URLs, and countdown dates.
- **[`TEMPLATE_SPEC.md`](./TEMPLATE_SPEC.md)**: Architecture deep dive, video compression guidelines (CRF 26-27), and accessibility standards.
