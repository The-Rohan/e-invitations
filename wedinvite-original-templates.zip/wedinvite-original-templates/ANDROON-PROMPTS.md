# Androon — Prompt Deck (template 7, after Riwaj)

The old walled city at blue hour: narrow cobbled gali, carved haveli doors,
jharoka balconies, brass lanterns, marigold garlands, a garlanded vintage sedan.
Built card: `card-androon.html` + `androon.html` (based on the Riwaj split card).
Assets live in `assets/androon/`.

Built so far from this deck (source images in `C:\Users\deskt\Downloads\new template`):

| asset | file | source plate |
|---|---|---|
| hero | `hero.jpg` | Old-city street at dusk |
| gate.mp4 / poster | `gate.mp4`, `gate-poster.jpg` | street → carved doorway film (HANDOFF 7.6 / 7.92 s) |
| venue | `venue.jpg` | carved double door under marigolds |
| dress | `dress.jpg` | guests walking the dusk lane |
| timeline frame | `tl-frame.jpg` | mehndi table on the balcony |

## Palette (locked — matches androon.css `:root`)

```
--paper:#F5EBD8   (aged cream paper)
--paper-2:#FCF6EA --panel:#F0E4CB --linen:#FCF8ED
--ink:#3E2A20     (warm sepia ink)
--ink-2:#634F3A   --muted:#A18762 --faint:#C7B28F
--accent:#D98E2B  (lantern amber)
--art:#C1632E     (persimmon)
--line:#E7D9BE
Desktop shell bg: #2A2029 (dusk plum-charcoal)
```

## Shared style suffix (append to every prompt)

> …in a vintage storybook illustration style: traditional gouache painting with
> soft translucent watercolor washes, visible brushwork and subtle paper grain,
> thin cream paper border framing the scene. Old walled city of Punjab at dusk:
> narrow cobblestone lane, carved wooden jharoka balconies, arched doorways in
> aged brick and lime plaster. Glowing brass filigree lanterns, strings of warm
> fairy lights, cascades of marigold garlands. Deep indigo-violet night sky
> melting into violet haze above, warm amber light pooling below. Palette of
> sepia browns, persimmon orange, deep gold, and indigo-violet. No people unless
> stated; no text, no lettering, no signature.

## Scene art — portrait 768×1376 (hero + section plates)

- **Hero / gate handoff still** — "Down a narrow cobblestone lane of the old
  walled city at blue hour, wet stones reflecting lantern light, marigold
  garland swags and fairy-light strings strung wall to wall overhead, carved
  wooden balconies leaning in on both sides, domes and a minaret silhouetted in
  the violet haze far ahead, a glowing lantern bracket at the left, empty street
  in perspective toward a warm-lit carved wooden door in the distance."
- **Invitation plate** — carved haveli double door, marigold curtains, two
  lanterns flanking, fairy lights along the scalloped arch.
- **Mehndi plate** — balcony terrace over the lane: brass platters of henna
  cones, paisley patterns on linen, bangles, petals, garlanded railing.
- **Baraat plate** — empty haveli courtyard at night, garlanded arches, dhol
  drum wrapped in marigolds on a carpet.
- **Walima plate** — the street set for the feast: long tables down the cobbled
  lane, brass urns, saffron runners, flower-ringed doorways, violet sky.
- **Farewell plate** — ivory-classic sedan before the grand gate, garlanded,
  petals on the bonnet, lanterns and mist behind.
- **Guests plate** — guests in jewel-toned formal wear walking the dusk lane
  with gift boxes and sweets trays toward a glowing doorway.

## Motif set (on aged-cream ground, multiply-friendly, ~square) — TODO

Still using the Riwaj ink motifs (cypress/diya/dholak/lotus) as placeholders.
Regenerate in Androon ink style when the art session resumes:

- **motif-lantern** — hanging brass filigree lantern, ink line on cream
- **motif-garland** — marigold string with jasmine drops, ink on cream
- **motif-door** — carved door head scallop, ink on cream
- **motif-dhol** — dhol drum with garland, ink on cream

## Gate film spec

720×1280, muted, H.264 faststart, target ≤3 MB (**current build 3.97 MB —
recompress to CRF 26–27 at the polish pass**). Poster = first frame.
`HANDOFF=7.6` on 7.92 s (SSIM vs hero peaks at the end; no frozen tail —
never wait for `ended`).

## Copy hooks

Venue voice: Androon Haveli, Kucha Androon, Walled City, Lahore. Lanterns,
garlands, the gali, blue hour. All built copy lives in `card-androon.html` and
the EVENTS table in `assets/androon/androon.js`.
