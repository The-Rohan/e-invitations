# wedinvite — Card Template Spec

Rules for building/converting wedding invitation card templates in this project.
Written from the **Baradari** reference implementation (June 2026). Future sessions
must follow these rules so all templates stay consistent.

## Project structure

```
index.html                      # demo shell for the Gulistan template (same pattern as baradari.html)
baradari.html                   # demo shell for the Baradari template
shabistan.html                  # demo shell for the Shabistan template (dark night courtyard)
basant.html                     # demo shell for the Basant template (daytime rooftops & kites)
khat.html                       # demo shell for the Khat template (a letter; wax-seal hold)
charkha.html                    # demo shell for the Charkha template (indigo block-print; spin-the-wheel)
riwaj.html                      # demo shell for the Riwaj template (editorial heritage; boot-loader handshake)
card-baradari.html              # the actual invitation card (loaded into the shell's iframe)
card-gulistan.html              # the actual invitation card for Gulistan
card-shabistan.html             # Shabistan: split card (HTML + assets/shabistan/{shabistan.css,shabistan.js})
card-basant.html                # Basant: split card (HTML + assets/basant/{basant.css,basant.js})
card-khat.html                  # Khat: split card (HTML + assets/khat/{khat.css,khat.js})
card-charkha.html               # Charkha: split card (HTML + assets/charkha/{charkha.css,charkha.js})
card-riwaj.html                 # Riwaj: split card (HTML + assets/riwaj/{riwaj.css,riwaj.js}); first card with a shell boot loader
assets/
  card-boot.js                  # shared: card boot + iOS Low Power Mode video play() emulation
  card-celebration.js           # shared: NiruCelebrate petals + NiruAutoScroll
  music.mp3                     # THE default bgm track for every template from now on (2:44, owner decision)
  baradari/                     # template folder: CSS, JS, fonts, images, og.jpg, gate.mp4
  shabistan/                    # template folder: dark palette, gold screen-blend motifs, lanterns
    shabistan.css / shabistan.js / fonts/*.woff2 / gate.mp4 + gate-poster.jpg
assets/iphone-mockup-20260921.webp   # desktop demo frame image (shared)
```

Two-layer architecture:

1. **`<name>.html` (demo shell)** — marketing page. Wraps the card in an iPhone
   mockup on desktop, full-screen on mobile. Contains the "Buy / Make it Yours" CTA.
2. **`card-<name>.html` (card)** — what a real guest receives. Self-contained:
   loads `assets/card-boot.js` + `assets/card-celebration.js` + its own
   `assets/<name>/<name>.css` and `assets/<name>/<name>.js`.

## Demo shell rules (`baradari.html` pattern)

- **Mobile (<760px)**: `.demo-device` is `position:fixed;inset:0`, iframe fills the
  screen, no fake chrome. Never show the iPhone frame on phones.
- **Mobile "Book" bar** (`.demo-book`, "Make it Yours"): slides in only once the
  guest has scrolled ~80% of a viewport into the card (shell polls
  `frame.contentDocument` scroll events) **or 25 s after the card loads**. It must
  never appear over the gate entrance.
- **Desktop (≥760px)**: card rendered at BASE width **402 px**, scaled with
  `transform:scale()` to fit the mockup screen area left between the iOS status bar
  (`--statusH = width * 0.1256`, 54pt) and Safari bar (`--safariH = width * 0.2047`,
  88pt). Chrome is sized off screen **width**, not height. Debounced on resize
  (150 ms). "Get now" button lives inside the fake Safari URL bar row.
- Iframe is given `allow="autoplay; fullscreen"`; a `?v=` cache-bust query on the
  iframe src; no-cache meta tags in the shell.

## Card structure (`card-baradari.html` pattern)

Mandatory head order: `card-boot.js` → `card-celebration.js` → charset/viewport →
preloads (gate poster, hero, two key fonts) → template CSS. `body` starts with
class `locked` (scroll locked until the gate is entered).

Anatomy (fixed order):

1. `.stage > .phoneWrap`
   - `.fabs` — fixed top control pill (z-index 90): music FAB (EQ bars), text-size
     FAB (`A<s>A`), language FAB (اردو ⇄ EN). Hidden until `phoneWrap.ui-on`;
     auto-hidden on scroll down (`fabs-hidden`), restored on scroll up / near top.
   - `.mapDock` — fixed bottom pill (z-index 88): "Map" (garden map modal) +
     "Reply →" (smooth-scroll to `#rsvp`).
   - `.phone` — the scrollable card.
2. `.entrance` (fixed, z-index 100) — the **gate**: full-bleed looping `<video>`
   (`gate.mp4`, muted, poster required), shade gradient, monogram + sound toggle
   top, kicker / names / **Enter** button / hint at bottom.
3. `#bodyMain` sections: `.hero` → panels/sections → `footer.foot` → `.grain`
   overlay (z-50 SVG noise, mix-blend multiply).
4. After the main stage: `.mapModal` (bottom sheet on mobile, centered on desktop;
   focus-trapped, Escape closes) and `<audio id="bgm">`.

Section order is fixed: hero → invitation (bismillah, verse, families, lede,
countdown) → date reveal (key + lock interaction) → events → dress code → stay →
travel → RSVP → footer.

## Gate → hero flow

- **State**: `opened`, plus `body.locked`. Nothing scrolls before entry.
- On "Enter" (button or any tap on the entrance except the sound toggle):
  `opened=true`, add `.playing` to entrance (gate UI fades), then
  `NiruBoot.play(gateVid)`.
- **Handoff constant** `HANDOFF` (seconds into the film): a
  `requestAnimationFrame` watcher checks `gateVid.currentTime >= HANDOFF` — that is
  when the gate video best matches the `hero` artwork — then calls
  `finishGate()`. If playback fails (`NiruBoot.play` rejects, or the `ended` event,
  or source error → `hasFilm=false`), finish immediately. **The film must never
  block the guest.**
- **Measuring HANDOFF for a new film (ffmpeg):** strip audio first, then
  `freezedetect` (no frozen tail → don't wait for `ended`), and run per-frame SSIM
  of candidate frames (5s→end, fps≈4) against the hero still:
  `ffmpeg -ss T -i gate.mp4 -frames:v 1 f.png` then
  `ffmpeg -i f.png -i hero.jpg -filter_complex "[1]scale=WxH[b];[0][b]ssim"`.
  Pick the time where All-SSIM is at/near its peak (Shabistan's rises to 0.59 at
  the end; `HANDOFF=7.55` on a 7.92s film). Baradari `6.35` of a 7s film,
  Gulistan `7.5` of 8.83s.
- `finishGate()`: entrance gets `.fade` (1.2 s opacity), after 280 ms `land()` →
  scroll to 0, `hero.classList.add('entered')` (hero copy fades/rises in via CSS),
  `body.locked` removed, `phoneWrap.ui-on` added (fabs + mapDock slide in). After
  1500 ms entrance gets `.gone` and the video is paused.
- `prefers-reduced-motion` or no-film: skip straight to `land()`.
- **card-boot.js contract**: `NiruBoot.run(fn)` runs after DOM + shell ready; its
  `play()` patches `HTMLMediaElement.play` so iOS Low Power Mode (which only
  authorises on touch *release*) still animates the gate by seek-emulation, and
  shows a "Tap to play" retry button only as last resort. Cards must go through
  `NiruBoot.play()`, never bare `video.play()`.

## Music behavior

- **One shared track for all templates** — `assets/music.mp3` (2:44). The same
  `<audio id="bgm" src="assets/music.mp3">` on every card; per-template copies are
  no longer made.
- `musicWanted=true` defaults; `musicOn` = actually playing; `bgm.volume` starts 0.
- **First-gesture autoplay**: `pointerdown`/`keydown`/`touchend` (capture) call
  `musicGesture()` → if `musicWanted` and not on the sound controls, `startMusic()`
  (play at volume 0, fade to **0.6** over ~1.8 s once the promise resolves; on
  rejection keep `musicOn=false`). Also triggered once at init.
- **Sound toggles**: gate sound pill (`#gateSound`) and the music FAB share state.
  Toggle off = `musicWanted=false` + fade to 0 (450 ms) then pause. Toggle on =
  restart `startMusic()`. Click handlers `stopPropagation()` so they don't double as
  entry/musk gestures.
- **Visibility**: on `visibilitychange`, pause (no fade) when hidden; restart via
  `startMusic()` when visible again if `musicWanted`. Fades are token-guarded
  (`fadeToken`) so overlapping fades never fight.
- The gate video is **always muted** (`updateSoundLabel()` sets `gateVid.muted=true`
  every time) — music comes only from `#bgm`.
- Music FAB visual: EQ bars animate when playing; `.muted` class when off.
- Labels/i18n live in the `STR` table (`soundOn/soundOff` etc).

## Mobile layout rules (card)

- Default = mobile-first, single column, `100dvh` hero.
- Desktop (≥760px): card becomes a phone-width column
  (`.phoneWrap{width:min(46vh,470px)}`) centered on the forest-green radial
  background; `mapModal` centers instead of bottom-sheets.
- Type scale via CSS custom props: `--ds` divisor set by the text-size FAB
  (steps 100/112/125%, base 16px, persisted in localStorage as
  `<name>-tsz`); big type uses `calc(4.2rem * var(--ds))` etc.
- Fonts (self-hosted woff2 in the template folder): display serif (Marcellus),
  body serif (Lora), script (Italianno), caps sans (Jost), Arabic (Amiri stack),
  Urdu (Noto Nastaliq Urdu stack).
- **Bilingual EN/UR**: every translatable string carries `data-ur="..."` (and
  `data-ur-ph` for placeholders). `setLang()` swaps innerHTML, caches the EN
  original in `dataset.en`, stores `<name>-lang` in localStorage, toggles
  `body.urdu`, and re-renders all dynamic blocks. Urdu mode: RTL, Urdu type
  overrides sized ~×1.4 line-height 2, mirrored flex rows, digits converted via
  `num()`/Eastern Arabic numerals, phone numbers stay LTR (`unicode-bidi:isolate`).
- Fixed-section theme: alternating paper (`--paper`/noise) and forest sections
  (`revealSec`, `travelSec`, `foot`); decorative multiply-blend art (columns, archs,
  urns, lamps, fountains) sourced from the template folder.
- Scroll reveals: `.rv` blocks, children get `.stag` + transition-delay stagger
  (80 ms per child), one IntersectionObserver adds `.in` once.
- Interactions that must remain: draggable key → lock (pointer events, 72 px
  drop radius, tap = unlock) **or the Shabistan lantern reveal** (three taps,
  `unlockDate()` when all lit), countdown tick (1 s interval, DST-safe
  `+05:00` target date), per-event calendar popovers (gcal URL + .ics data-URI),
  RSVP form (per-event yes/no + guest stepper 1–10, fake submit → thanks state +
  `NiruCelebrate` petals), scroll-margin-top on all anchor targets.
- Share one `<audio id="bgm">` for the bell: card posts `niru:map-open` /
  `niru:map-close` to the parent shell; the shell hides the "Make it Yours" pill
  while a fullscreen modal is open (see the Shabistan section).

## Shabistan-specific notes (third template, dark-theme pilot)

- Dark palette via the same variables — `--paper:#12213A`, `--forest:#0A0F1D`,
  cream/ink inverted, gold `#C9A25E`. Vars carry the theme; only the few
  hardcoded gradients needed manual swaps.
- **Lantern reveal** replaces key/lock: three `.lanternBtn` (tap each → `.lit`),
  `unlockDate()` fires when all three are lit. `.dateReveal` overlay must carry
  `pointer-events:none` until `.unlocked` (caught in QA).
- Gold-on-black motifs → `mix-blend-mode:screen`; multiply is only for light
  backgrounds (Shabistan uses screen for cypress/arch/lantern art, RVSP bg, footer).
- Film pipeline: source muted + recompressed (CRF 24 → 2.38 MB), first frame
  extracted as `gate-poster.jpg`, `HANDOFF=7.55` on a 7.917 s film.
- Keep `gate-original.mp4` alongside until the visual check is approved; delete it
  after sign-off.

## Basant-specific notes (fourth template, light daytime)

Light palette via the same variables — `--paper:#F8F4EA`, `--forest:#1F3A44` (ink
teal), marigold `#D9863B`, kaghazi `#E9B44C`. Reveal is the **kite variant** of the
three-tap marker (`.kiteRow` / `.kiteBtn`, `unlockDate()` when all three lift) —
same JS as Shabistan's lanterns, renamed. Event motif images are **not** used; the
`.evTop` plate carries a CSS kite-diamond instead, and `.panelColumn` is a CSS
bunting string. Scene art is portrait 768×1376 throughout (all images 1.82MB
optimized). Film: 720×1280 @ 7.917s, 2.21 MB, near-pixel hero match (SSIM 0.93 at
the end); `HANDOFF=7.55`, poster = first frame.

## Khat-specific notes (fifth template, the letter — interaction outliers live here)

A typographic letter, not a page of scenes: no map dock/modal, no scenePlate art;
sections are hairline-separated (`letterSec + letterSec`), corner `sprig` images
multiply-blend, events/dress cards are paper notes and `.evTop` is hidden.

- **Wax-seal hold reveal** — `#sealBtn` with an SVG progress ring (dasharray 283,
  `HOLD=1.15 s`). Hold to 1 → `unlockDate()`; release early → `.cool` shake, ring
  resets. Keyboard hold (Space/Enter) and a reduced-motion click fallback wired.
  Both early-release and full-hold paths QA-verified.
- **Thread navigation** — `#threadNav` on the right edge (mirrored in Urdu): seven
  knots built from the `SECTIONS` table; one IntersectionObserver (`rootMargin
  -40%`) marks the active knot, and a tap scrolls to the section. Replaces
  `mapDock`/`mapModal` entirely — the map-open pill handshake is not needed.
- Film: 720×1280 @ 10.0 s, 1.63 MB, frozen tail detected at 9.33 s, SSIM ~0.77
  from 8 s onward; **`HANDOFF=8.9`**, poster = sealed-envelope first frame.
- Lesson for future blocks: never embed Urdu in PowerShell patches (ANSI decode
  mangles it); apply Urdu string changes with the file editor after an ASCII patch.

## Charkha-specific notes (sixth template, indigo block-print)

Palette via the same variables — `--paper:#F3EAD8`, `--forest:#1F2E4D` (deep
indigo), clay `#A65E3F`, brass `#C98E3E`; reveal/travel/foot sections are indigo
bands like Baradari's. Film: 720×1280 @ 7.917s, 2.94 MB (closest to the 3 MB
ceiling), no frozen tail, SSIM 0.90 at the end; **`HANDOFF=7.55`**, poster = first
frame (wheel close-up).

- **Spin-the-wheel reveal** — `#wheelBtn` (round, walnut rim + `#wheelImg`
  rotating, handle knob). Pointer-angle drag accumulates degrees; **3 full
  clockwise turns = 1080°** lights the three `#bobbinRow i` markers one per turn;
  release while short leaves progress wound (turns persist across grabs — the
  thread keeps); a `momentum()` decay lets a flick finish the turn. `finish()` is
  recursion-safe on purpose: it does **not** call `stopDrag()`/`momentum()`, and
  `paint()` never triggers `finish()` — QA caught a stack overflow from exactly
  that loop. Reduced-motion fallback: each click winds one turn.
- `.evTop` uses the CSS kite-diamond; `.panelColumn` is a CSS bunting string;
  `reel.jpg` (bobbin artwork) serves RSVP/thanks plates; footer carries
  `foot-cloth.jpg`. Map dock/modal + pill handshake kept as-is.

## Riwaj-specific notes (seventh template, editorial heritage — new shared polish lives here)

- The "modern editorial" skin: oat paper `#F5EFE4`, plum-brown ink `#3D2B33`,
  marigold `#C08A3E` for type accents only, madder `#8A3B4A` kept in art.
  Display face is **Playfair Display italic 600** (`assets/fonts/playfair
  -italic-600.ttf`, self-hosted for the first time) + Jost caps/body.
- **Shell boot loader handshake** (adopted from the Niru reference, now the
  shell pattern for future templates): the shell shows a branded loader with a
  progress line, holds the iframe at `opacity:0`, and connects via (a) polling
  the card's `documentElement.dataset.niruLoadState`, (b) listening for
  `niru:card-shell-ready` / `niru:card-ready` CROSS-events + messages
  (card-boot.js already emits both), (c) a 4.5 s fallback so it can never hang.
  The iframe fades in at `.card-ready` and the loader is removed after 260 ms.
- **Hold-to-ink reveal**: three `.sealTile` circles in `#seals`, values from
  `REVEAL`. Cover = CSS wax layers (`.glaze` hatch + `.wax` paper), whose
  opacity is tied to `--wax` (0..1) driven by a rAF timer, HOLD=0.8 s. Release
  early → cool back 0.2; all three → `.inked` + `revDone` + `NiruCelebrate`.
  Keyboard hold (Space/Enter) and reduced-motion click ink instantly. Values
  update in place on `setLang` (progress preserved).
- **Letter-typing hero names**: spans with per-letter `<i>` (blur-to-sharp,
  75 ms stagger, second name +0.30 s); Urdu reveals word-by-word (ligatures).
  Re-run on language change.
- **New sections**: 4-cell countdown (D/H/M/S, labels outside boxed cells),
  square-outlined map button, `Timeline` rows inside `tl-frame.jpg` (window
  x21%-80% / y16%-88%), `dressArt` figures, `Transportation` + `Accommodation`
  info cards, and a deckle-edge closing card in pure CSS `clip-path`.
- Film: 720×1280 @ 10.0 s, 1.56 MB; motion holds from 8.5 s (freezedetect),
  SSIM plateaus ~0.61; **`HANDOFF=8.35`** (dissolve while still moving).

## Shared helpers

- `NiruCelebrate(msg, {colors,count,duration})` — petal shower overlay; pass
  `msg=false` when the card already showed its own message (as Baradari does).
  Petals use the template palette.
- `NiruAutoScroll` — slow auto-scroll tour; always user-cancellable; disabled under
  reduced motion.
- `prefers-reduced-motion` must be respected everywhere (`reduce` flag gates all
  animation/JS motion).

## Adding a new template checklist

1. Copy `card-baradari.html` → `card-<name>.html`; create `assets/<name>/`
   (css/js/fonts/og.jpg/gate film poster). Keep the two shared scripts
   (`card-boot.js`, `card-celebration.js`) referenced from `assets/`, and point the
   `<audio id="bgm">` at the shared `assets/music.mp3` — do not copy a new track
   per template.
2. Keep gate → hero handoff, music, fabs/mapDock, bilingual, text-size, and demo
   shell behaviors identical; only theme (palette, art, copy, section content)
   changes.
3. Demo shell: copy `baradari.html` or `shabistan.html` → `<name>.html`, update
   title/OG/description, iframe src (`?v=`), CTA href (`order?tpl=<name>`) and hint
   line. Keep the `BASE=402` scaling and `.demo-book` scroll rules untouched, and
   include the `niru:map-open`/`niru:map-close` pill guard (Shabistan shell).
4. Films: mute (`-an`), H.264 `faststart`, target ≤3 MB (Shabistan: CRF 24 →
   2.38 MB), extract first frame as the poster, measure `HANDOFF` with SSIM.
5. Base mobile width is **402 px** — design to that, and keep the demo shell and
   any future desktop mockup logic in sync with it.
