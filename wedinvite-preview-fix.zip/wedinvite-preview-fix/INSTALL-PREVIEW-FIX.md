# Install the admin invitation preview fix on Mac

1. Stop your running app with Control+C.
2. Extract wedinvite-preview-fix.zip.
3. Merge the extracted patch into your EXISTING app folder using Terminal:

   ditto ~/Downloads/wedinvite-preview-fix /path/to/your/wedinvite-app-crm

Replace the destination path with your actual app folder. You can drag that folder into Terminal to insert its path. The destination must contain package.json. `ditto` merges the folders; it does not delete your other files. Do not replace entire app/components folders in Finder.

Alternatively, replace just these three files with the matching files from this patch:
- app/api/invitation/[id]/route.ts
- app/invite/[id]/page.tsx
- components/Invitation.tsx

No dependency changes are needed. The patch contains no .data or .env.local and must not replace them.

4. In your existing app folder run npm run dev. If you run production mode, run npm run build then npm start instead.
5. Open a saved invitation through the admin dashboard Preview link. At desktop widths (760px+) it uses the original phone mockup; on mobile it fills the screen. Saved customer details, draft privacy and RSVP remain connected.
